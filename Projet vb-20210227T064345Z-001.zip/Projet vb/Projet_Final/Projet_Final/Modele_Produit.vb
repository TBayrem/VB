﻿Public Class Modele_Produit
    Inherits Control

    Private GB As New GroupBox
    Private B As New Button
    Private l As New Label
    Private l1 As New Label
    Private l2 As New Label
    Private l3 As New Label
    Private B1 As New Button
    Private t As New TextBox
    Private B2 As New Button

    Public Sub New()
     
    End Sub


    Public Function model(nom As String, img1 As Image, prix As Decimal, prix_a As Decimal, qte As Decimal) As GroupBox

        GB.Text = nom

        B.BackgroundImage = img1
        B.BackgroundImageLayout = ImageLayout.Stretch
        B.SetBounds(5, 15, 100, 100)
        AddHandler B.Click, AddressOf ClickHandlerB
        l.Text = "Prix : " + CStr(prix)
        l.SetBounds(2, 120, 100, 20)

        l2.Text = CStr(prix_a)

        l3.Text = CStr(qte)

        l1.Text = "Qte : "
        l1.SetBounds(2, 140, 100, 30)


        B1.SetBounds(25, 2, 20, 20)
        B1.BackgroundImage = Image.FromFile(img + "Moin.png")
        B1.BackgroundImageLayout = ImageLayout.Stretch
        AddHandler B1.Click, AddressOf ClickHandlerB1

        B2.SetBounds(69, 2, 20, 20)
        B2.BackgroundImage = Image.FromFile(img + "Plus.png")
        B2.BackgroundImageLayout = ImageLayout.Stretch
        AddHandler B2.Click, AddressOf ClickHandlerB2



        t.SetBounds(47, 2, 20, 20)
        t.Text = "0"
        t.TextAlign = HorizontalAlignment.Center


        l1.Controls.Add(B1)
        l1.Controls.Add(B2)
        l1.Controls.Add(t)



        GB.AutoSize = True

        GB.Controls.Add(B)
        GB.Controls.Add(l)
        GB.Controls.Add(l1)
        If CInt(l3.Text) <= Seil Then
            GB.BackColor = Color.OrangeRed

        End If
        If CInt(l3.Text) <= 0 Then
            GB.BackColor = Color.Red

        End If
        Return GB

    End Function



    Public Sub ClickHandlerB2(sender As Object, e As EventArgs)
        If CInt(t.Text) < CInt(l3.Text) Then
            t.Text = CStr(CInt(t.Text) + 1)
        End If

    End Sub
    Public Sub ClickHandlerB1(sender As Object, e As EventArgs)
        If CInt(t.Text) > 0 Then
            t.Text = CStr(CInt(t.Text) - 1)
        End If
    End Sub

    Public Sub ClickHandlerB(sender As Object, e As EventArgs)


        Dim ch As String = l.Text.Remove(0, 7)
        If IsNumeric(t.Text) = True Then
            If CInt(t.Text) <> 0 Then


                Dim trouve As Boolean = False
                Dim j As Integer = 0
                Dim n As Integer = Ventesvb.DGV_COMM.RowCount

                While trouve = False And j < n - 1

                    If CStr(Ventesvb.DGV_COMM.Item(2, j).Value) = GB.Text Then
                        trouve = True
                    Else
                        j = j + 1
                    End If

                End While
                If trouve = True Then
                    Ventesvb.DGV_COMM.Item(1, j).Value = t.Text
                    Ventesvb.DGV_COMM.Item(6, j).Value = CInt(t.Text) * CInt(ch)
                    Ventesvb.DGV_COMM.Item(5, j).Value = CInt(t.Text) * CInt(l2.Text)
                Else
                    Ventesvb.DGV_COMM.RowCount = Ventesvb.DGV_COMM.RowCount + 1
                    Ventesvb.DGV_COMM.Item(0, n - 1).Value = l3.Text
                    Ventesvb.DGV_COMM.Item(1, n - 1).Value = t.Text
                    Ventesvb.DGV_COMM.Item(2, n - 1).Value = GB.Text
                    Ventesvb.DGV_COMM.Item(3, n - 1).Value = l2.Text
                    Ventesvb.DGV_COMM.Item(4, n - 1).Value = ch
                    Ventesvb.DGV_COMM.Item(5, n - 1).Value = CInt(t.Text) * CInt(l2.Text)
                    Ventesvb.DGV_COMM.Item(6, n - 1).Value = CInt(t.Text) * CInt(ch)


                End If
                Dim y As Double = 0
                Dim x As Double = 0
                For j = 0 To n - 1
                    y = y + CDbl(Ventesvb.DGV_COMM.Item(6, j).Value)
                    x = x + CDbl(Ventesvb.DGV_COMM.Item(5, j).Value)
                Next



                Ventesvb.Totaux1.Text = "Totaux de vente :" + CStr(y)
                Ventesvb.Totaux2.Text = "Totaux d'achat   :" + CStr(x)
                Ventesvb.Btn_Valider.Enabled = True
            End If
        End If

    End Sub
End Class
