﻿Public Class Compte

    Private Sub Compte_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Btn_Logout.BackgroundImage = Image.FromFile(img + "logout.png")
        Btn_Logout.BackgroundImageLayout = ImageLayout.Stretch
        Btn_Clavier.SetBounds(570, 750, 165, 20)

        Btn_Logout.SetBounds(1300, 10, 50, 50)


        Me.AddOwnedForm(Ventesvb)



        Ventesvb.Btn_Hot.Enabled = False
        Ventesvb.Btn_Ice.Enabled = False
        Ventesvb.Btn_Pastries.Enabled = False
        Ventesvb.Btn_Smoothies.Enabled = False
        Dim ch As String
        Dim i As Integer
        For i = 0 To n - 1
            If Vendeur.GetData.Rows.Item(i).ItemArray(0) = id_vc Then
                ch = Vendeur.GetData.Rows.Item(i).ItemArray(4)
            End If


        Next




        If Ventesvb.Btn_Hot.Text = ch Then
            Ventesvb.Btn_Hot.Enabled = True
        End If
        If Ventesvb.Btn_Ice.Text = ch Then
            Ventesvb.Btn_Ice.Enabled = True
        End If
        If Ventesvb.Btn_Smoothies.Text = ch Then
            Ventesvb.Btn_Smoothies.Enabled = True
        End If
        If Ventesvb.Btn_Pastries.Text = ch Then
            Ventesvb.Btn_Pastries.Enabled = True
        End If
        Ventesvb.Show()
    End Sub

    Private Sub Btn_Logout_Click(sender As Object, e As EventArgs) Handles Btn_Logout.Click
        Me.Close()
        Ventesvb.Close()
        Me.Close()

        Connnect.Show()

    End Sub

    Private Sub Btn_Clavier_Click(sender As Object, e As EventArgs) Handles Btn_Clavier.Click
        'importer le clavier virtuel
        Me.AddOwnedForm(Clavier)
        If iclavier = 0 Then
            Clavier.Show()
            Clavier.SetBounds(390, 585, 560, 164)
            iclavier = 1
        Else

            Clavier.Hide()
            iclavier = 0

        End If
    End Sub
End Class