﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ajouter
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txt_Id_V = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt_Nom = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txt_Log = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt_Pass = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.PA_Vendeur = New System.Windows.Forms.Panel()
        Me.CB_CP = New System.Windows.Forms.ComboBox()
        Me.PA_Produit = New System.Windows.Forms.Panel()
        Me.CB_CPA = New System.Windows.Forms.ComboBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txt_Qte = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt_Id_P = New System.Windows.Forms.TextBox()
        Me.txt_PV = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Txt_PA = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txt_lib = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Btn_Ajout = New System.Windows.Forms.Button()
        Me.Btn_Annul = New System.Windows.Forms.Button()
        Me.PA_Vendeur.SuspendLayout()
        Me.PA_Produit.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(16, 4)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "ID : "
        '
        'txt_Id_V
        '
        Me.txt_Id_V.Location = New System.Drawing.Point(166, 3)
        Me.txt_Id_V.Name = "txt_Id_V"
        Me.txt_Id_V.Size = New System.Drawing.Size(124, 20)
        Me.txt_Id_V.TabIndex = 1
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(16, 30)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(107, 15)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Nom & Prenom : "
        '
        'txt_Nom
        '
        Me.txt_Nom.Location = New System.Drawing.Point(166, 29)
        Me.txt_Nom.Name = "txt_Nom"
        Me.txt_Nom.Size = New System.Drawing.Size(124, 20)
        Me.txt_Nom.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(16, 56)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 15)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Login : "
        '
        'txt_Log
        '
        Me.txt_Log.Location = New System.Drawing.Point(166, 55)
        Me.txt_Log.Name = "txt_Log"
        Me.txt_Log.Size = New System.Drawing.Size(124, 20)
        Me.txt_Log.TabIndex = 5
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(16, 82)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(89, 15)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Passworod : "
        '
        'txt_Pass
        '
        Me.txt_Pass.Location = New System.Drawing.Point(166, 81)
        Me.txt_Pass.Name = "txt_Pass"
        Me.txt_Pass.Size = New System.Drawing.Size(124, 20)
        Me.txt_Pass.TabIndex = 7
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(16, 108)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 15)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Catégorie du Produit : "
        '
        'PA_Vendeur
        '
        Me.PA_Vendeur.Controls.Add(Me.CB_CP)
        Me.PA_Vendeur.Controls.Add(Me.Label1)
        Me.PA_Vendeur.Controls.Add(Me.Label4)
        Me.PA_Vendeur.Controls.Add(Me.txt_Id_V)
        Me.PA_Vendeur.Controls.Add(Me.txt_Log)
        Me.PA_Vendeur.Controls.Add(Me.Label2)
        Me.PA_Vendeur.Controls.Add(Me.txt_Pass)
        Me.PA_Vendeur.Controls.Add(Me.Label3)
        Me.PA_Vendeur.Controls.Add(Me.txt_Nom)
        Me.PA_Vendeur.Controls.Add(Me.Label5)
        Me.PA_Vendeur.Location = New System.Drawing.Point(22, 26)
        Me.PA_Vendeur.Name = "PA_Vendeur"
        Me.PA_Vendeur.Size = New System.Drawing.Size(308, 144)
        Me.PA_Vendeur.TabIndex = 10
        '
        'CB_CP
        '
        Me.CB_CP.FormattingEnabled = True
        Me.CB_CP.Items.AddRange(New Object() {"Hot Drinks", "Ice Drinks", "Smoothies", "Pasteries"})
        Me.CB_CP.Location = New System.Drawing.Point(166, 107)
        Me.CB_CP.Name = "CB_CP"
        Me.CB_CP.Size = New System.Drawing.Size(124, 21)
        Me.CB_CP.TabIndex = 9
        '
        'PA_Produit
        '
        Me.PA_Produit.Controls.Add(Me.CB_CPA)
        Me.PA_Produit.Controls.Add(Me.Label11)
        Me.PA_Produit.Controls.Add(Me.txt_Qte)
        Me.PA_Produit.Controls.Add(Me.Label6)
        Me.PA_Produit.Controls.Add(Me.Label7)
        Me.PA_Produit.Controls.Add(Me.txt_Id_P)
        Me.PA_Produit.Controls.Add(Me.txt_PV)
        Me.PA_Produit.Controls.Add(Me.Label8)
        Me.PA_Produit.Controls.Add(Me.Txt_PA)
        Me.PA_Produit.Controls.Add(Me.Label9)
        Me.PA_Produit.Controls.Add(Me.txt_lib)
        Me.PA_Produit.Controls.Add(Me.Label10)
        Me.PA_Produit.Location = New System.Drawing.Point(12, 12)
        Me.PA_Produit.Name = "PA_Produit"
        Me.PA_Produit.Size = New System.Drawing.Size(292, 209)
        Me.PA_Produit.TabIndex = 11
        '
        'CB_CPA
        '
        Me.CB_CPA.FormattingEnabled = True
        Me.CB_CPA.Items.AddRange(New Object() {"Hot Drinks", "Ice Drinks", "Smoothies", "Pasteries"})
        Me.CB_CPA.Location = New System.Drawing.Point(148, 8)
        Me.CB_CPA.Name = "CB_CPA"
        Me.CB_CPA.Size = New System.Drawing.Size(124, 21)
        Me.CB_CPA.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(3, 8)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(151, 15)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Catégorie du Produit : "
        '
        'txt_Qte
        '
        Me.txt_Qte.Location = New System.Drawing.Point(172, 163)
        Me.txt_Qte.Name = "txt_Qte"
        Me.txt_Qte.Size = New System.Drawing.Size(100, 20)
        Me.txt_Qte.TabIndex = 9
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(22, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 15)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "ID : "
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(22, 138)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(95, 15)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Prix d'achat : "
        '
        'txt_Id_P
        '
        Me.txt_Id_P.Location = New System.Drawing.Point(172, 59)
        Me.txt_Id_P.Name = "txt_Id_P"
        Me.txt_Id_P.Size = New System.Drawing.Size(100, 20)
        Me.txt_Id_P.TabIndex = 1
        '
        'txt_PV
        '
        Me.txt_PV.Location = New System.Drawing.Point(172, 111)
        Me.txt_PV.Name = "txt_PV"
        Me.txt_PV.Size = New System.Drawing.Size(100, 20)
        Me.txt_PV.TabIndex = 5
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(22, 85)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(67, 15)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Libellé :  "
        '
        'Txt_PA
        '
        Me.Txt_PA.Location = New System.Drawing.Point(172, 137)
        Me.Txt_PA.Name = "Txt_PA"
        Me.Txt_PA.Size = New System.Drawing.Size(100, 20)
        Me.Txt_PA.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(22, 112)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(106, 15)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "Prix de vente :  "
        '
        'txt_lib
        '
        Me.txt_lib.Location = New System.Drawing.Point(172, 85)
        Me.txt_lib.Name = "txt_lib"
        Me.txt_lib.Size = New System.Drawing.Size(100, 20)
        Me.txt_lib.TabIndex = 3
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(22, 164)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(144, 15)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Quantité desponible :"
        '
        'Btn_Ajout
        '
        Me.Btn_Ajout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Ajout.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ajout.Location = New System.Drawing.Point(158, 249)
        Me.Btn_Ajout.Name = "Btn_Ajout"
        Me.Btn_Ajout.Size = New System.Drawing.Size(91, 40)
        Me.Btn_Ajout.TabIndex = 12
        Me.Btn_Ajout.Text = "Ajouter"
        Me.Btn_Ajout.UseVisualStyleBackColor = True
        '
        'Btn_Annul
        '
        Me.Btn_Annul.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Annul.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Annul.Location = New System.Drawing.Point(255, 250)
        Me.Btn_Annul.Name = "Btn_Annul"
        Me.Btn_Annul.Size = New System.Drawing.Size(91, 40)
        Me.Btn_Annul.TabIndex = 13
        Me.Btn_Annul.Text = "Annuler"
        Me.Btn_Annul.UseVisualStyleBackColor = True
        '
        'Ajouter
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(735, 566)
        Me.Controls.Add(Me.Btn_Annul)
        Me.Controls.Add(Me.Btn_Ajout)
        Me.Controls.Add(Me.PA_Produit)
        Me.Controls.Add(Me.PA_Vendeur)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Ajouter"
        Me.Opacity = 0.9R
        Me.Text = "Ajouter"
        Me.PA_Vendeur.ResumeLayout(False)
        Me.PA_Vendeur.PerformLayout()
        Me.PA_Produit.ResumeLayout(False)
        Me.PA_Produit.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txt_Id_V As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt_Nom As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txt_Log As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt_Pass As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents PA_Vendeur As System.Windows.Forms.Panel
    Friend WithEvents CB_CP As System.Windows.Forms.ComboBox
    Friend WithEvents PA_Produit As System.Windows.Forms.Panel
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt_Id_P As System.Windows.Forms.TextBox
    Friend WithEvents txt_PV As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Txt_PA As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txt_lib As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txt_Qte As System.Windows.Forms.TextBox
    Friend WithEvents Btn_Ajout As System.Windows.Forms.Button
    Friend WithEvents Btn_Annul As System.Windows.Forms.Button
    Friend WithEvents CB_CPA As System.Windows.Forms.ComboBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
End Class
