﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Afficher
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Produit_GV = New System.Windows.Forms.DataGridView()
        Me.IDPDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LIBELLEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRIXDEVENTEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRIXDACHATDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.QTEDESPDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PRODUITBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSet_coffe = New Projet_Final.DataSet_coffe()
        Me.VENDEURBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VENDEURTableAdapter = New Projet_Final.DataSet_coffeTableAdapters.VENDEURTableAdapter()
        Me.PRODUITTableAdapter = New Projet_Final.DataSet_coffeTableAdapters.PRODUITTableAdapter()
        Me.Vendeur_GV = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.NAMEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LOGINDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PASSWORDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CPDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.Produit_GV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PRODUITBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet_coffe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VENDEURBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Vendeur_GV, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Produit_GV
        '
        Me.Produit_GV.AutoGenerateColumns = False
        Me.Produit_GV.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader
        Me.Produit_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Produit_GV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDPDataGridViewTextBoxColumn, Me.LIBELLEDataGridViewTextBoxColumn, Me.PRIXDEVENTEDataGridViewTextBoxColumn, Me.PRIXDACHATDataGridViewTextBoxColumn, Me.QTEDESPDataGridViewTextBoxColumn})
        Me.Produit_GV.DataSource = Me.PRODUITBindingSource
        Me.Produit_GV.Location = New System.Drawing.Point(12, 12)
        Me.Produit_GV.Name = "Produit_GV"
        Me.Produit_GV.Size = New System.Drawing.Size(490, 122)
        Me.Produit_GV.TabIndex = 0
        '
        'IDPDataGridViewTextBoxColumn
        '
        Me.IDPDataGridViewTextBoxColumn.DataPropertyName = "ID_P"
        Me.IDPDataGridViewTextBoxColumn.HeaderText = "ID_P"
        Me.IDPDataGridViewTextBoxColumn.Name = "IDPDataGridViewTextBoxColumn"
        Me.IDPDataGridViewTextBoxColumn.Width = 56
        '
        'LIBELLEDataGridViewTextBoxColumn
        '
        Me.LIBELLEDataGridViewTextBoxColumn.DataPropertyName = "LIBELLE"
        Me.LIBELLEDataGridViewTextBoxColumn.HeaderText = "LIBELLE"
        Me.LIBELLEDataGridViewTextBoxColumn.Name = "LIBELLEDataGridViewTextBoxColumn"
        Me.LIBELLEDataGridViewTextBoxColumn.Width = 74
        '
        'PRIXDEVENTEDataGridViewTextBoxColumn
        '
        Me.PRIXDEVENTEDataGridViewTextBoxColumn.DataPropertyName = "PRIX_DE_VENTE"
        Me.PRIXDEVENTEDataGridViewTextBoxColumn.HeaderText = "PRIX_DE_VENTE"
        Me.PRIXDEVENTEDataGridViewTextBoxColumn.Name = "PRIXDEVENTEDataGridViewTextBoxColumn"
        Me.PRIXDEVENTEDataGridViewTextBoxColumn.Width = 120
        '
        'PRIXDACHATDataGridViewTextBoxColumn
        '
        Me.PRIXDACHATDataGridViewTextBoxColumn.DataPropertyName = "PRIX_DACHAT"
        Me.PRIXDACHATDataGridViewTextBoxColumn.HeaderText = "PRIX_DACHAT"
        Me.PRIXDACHATDataGridViewTextBoxColumn.Name = "PRIXDACHATDataGridViewTextBoxColumn"
        Me.PRIXDACHATDataGridViewTextBoxColumn.Width = 107
        '
        'QTEDESPDataGridViewTextBoxColumn
        '
        Me.QTEDESPDataGridViewTextBoxColumn.DataPropertyName = "QTE_DESP"
        Me.QTEDESPDataGridViewTextBoxColumn.HeaderText = "QTE_DESP"
        Me.QTEDESPDataGridViewTextBoxColumn.Name = "QTEDESPDataGridViewTextBoxColumn"
        Me.QTEDESPDataGridViewTextBoxColumn.Width = 89
        '
        'PRODUITBindingSource
        '
        Me.PRODUITBindingSource.DataMember = "PRODUIT"
        Me.PRODUITBindingSource.DataSource = Me.DataSet_coffe
        '
        'DataSet_coffe
        '
        Me.DataSet_coffe.DataSetName = "DataSet_coffe"
        Me.DataSet_coffe.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VENDEURBindingSource
        '
        Me.VENDEURBindingSource.DataMember = "VENDEUR"
        Me.VENDEURBindingSource.DataSource = Me.DataSet_coffe
        '
        'VENDEURTableAdapter
        '
        Me.VENDEURTableAdapter.ClearBeforeFill = True
        '
        'PRODUITTableAdapter
        '
        Me.PRODUITTableAdapter.ClearBeforeFill = True
        '
        'Vendeur_GV
        '
        Me.Vendeur_GV.AutoGenerateColumns = False
        Me.Vendeur_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Vendeur_GV.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.NAMEDataGridViewTextBoxColumn, Me.LOGINDataGridViewTextBoxColumn, Me.PASSWORDDataGridViewTextBoxColumn, Me.CPDataGridViewTextBoxColumn})
        Me.Vendeur_GV.DataSource = Me.VENDEURBindingSource
        Me.Vendeur_GV.Location = New System.Drawing.Point(12, 140)
        Me.Vendeur_GV.Name = "Vendeur_GV"
        Me.Vendeur_GV.Size = New System.Drawing.Size(544, 150)
        Me.Vendeur_GV.TabIndex = 1
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        '
        'NAMEDataGridViewTextBoxColumn
        '
        Me.NAMEDataGridViewTextBoxColumn.DataPropertyName = "NAME"
        Me.NAMEDataGridViewTextBoxColumn.HeaderText = "NAME"
        Me.NAMEDataGridViewTextBoxColumn.Name = "NAMEDataGridViewTextBoxColumn"
        '
        'LOGINDataGridViewTextBoxColumn
        '
        Me.LOGINDataGridViewTextBoxColumn.DataPropertyName = "LOGIN"
        Me.LOGINDataGridViewTextBoxColumn.HeaderText = "LOGIN"
        Me.LOGINDataGridViewTextBoxColumn.Name = "LOGINDataGridViewTextBoxColumn"
        '
        'PASSWORDDataGridViewTextBoxColumn
        '
        Me.PASSWORDDataGridViewTextBoxColumn.DataPropertyName = "PASSWORD"
        Me.PASSWORDDataGridViewTextBoxColumn.HeaderText = "PASSWORD"
        Me.PASSWORDDataGridViewTextBoxColumn.Name = "PASSWORDDataGridViewTextBoxColumn"
        '
        'CPDataGridViewTextBoxColumn
        '
        Me.CPDataGridViewTextBoxColumn.DataPropertyName = "CP"
        Me.CPDataGridViewTextBoxColumn.HeaderText = "CP"
        Me.CPDataGridViewTextBoxColumn.Name = "CPDataGridViewTextBoxColumn"
        '
        'Afficher
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.ClientSize = New System.Drawing.Size(662, 332)
        Me.Controls.Add(Me.Vendeur_GV)
        Me.Controls.Add(Me.Produit_GV)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Afficher"
        Me.Opacity = 0.9R
        Me.Text = "Afficher"
        CType(Me.Produit_GV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PRODUITBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet_coffe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VENDEURBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Vendeur_GV, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Produit_GV As System.Windows.Forms.DataGridView
    Friend WithEvents DataSet_coffe As Projet_Final.DataSet_coffe
    Friend WithEvents VENDEURBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VENDEURTableAdapter As Projet_Final.DataSet_coffeTableAdapters.VENDEURTableAdapter
    Friend WithEvents PRODUITBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PRODUITTableAdapter As Projet_Final.DataSet_coffeTableAdapters.PRODUITTableAdapter
    Friend WithEvents IDPDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LIBELLEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PRIXDEVENTEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PRIXDACHATDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents QTEDESPDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Vendeur_GV As System.Windows.Forms.DataGridView
    Friend WithEvents IDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NAMEDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LOGINDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents PASSWORDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents CPDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
