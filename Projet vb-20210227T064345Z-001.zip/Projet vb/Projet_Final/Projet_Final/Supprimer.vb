﻿Public Class Supprimer

    Private Sub Btn_search_Click(sender As Object, e As EventArgs) Handles Btn_search.Click
        Dim i As Integer = 0

        Dim trouve As Boolean = False
        If Admin.Titre.Text = Admin.Btn_Vendeur.Text Then

            While i <= n - 1 And trouve = False
                If CStr(Vendeur.GetData.Rows.Item(i).ItemArray(0)) = txt_supp.Text Then
                    trouve = True
                Else
                    i = i + 1
                End If
            End While

            If trouve = True Then
                FLP_Produit.Hide()
                FLP_Vendeur.Show()
                FLP_Vendeur.SetBounds(51, 86, 433, 148)
                lab_nom.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(1))
                Lab_login.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(2))
                Lab_password.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(3))
                Lab_cate.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(4))
                If txt_supp.Text = "1" Then

                    Admin.P_Notif.Show()
                    Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                    Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                    Admin.L_MSG.Text = "ID  ADmin"
                    Admin.L_Notif.Text = "Eurreur"
                    Btn_Supp.Enabled = False
                    Btn_Annul.Enabled = False
                Else
                    Admin.P_Notif.Show()
                    Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                    Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                    Admin.L_MSG.Text = "ID  trouvée"
                    Admin.L_Notif.Text = "Confirmation"
                    Btn_Supp.Enabled = True
                    Btn_Annul.Enabled = True
                End If
                
            Else
                FLP_Vendeur.Hide()
                FLP_Produit.Hide()
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "ID non trouvée"
                Admin.L_Notif.Text = "Eurreur"
                Btn_Supp.Enabled = False
                Btn_Annul.Enabled = False
            End If

        Else

            While i <= m - 1 And trouve = False
                If CStr(Produit.GetData.Rows.Item(i).ItemArray(0)) = txt_supp.Text Then
                    trouve = True
                Else
                    i = i + 1
                End If
            End While
            If trouve = True Then
                FLP_Vendeur.Hide()
                FLP_Produit.Show()
                FLP_Produit.SetBounds(51, 86, 433, 148)
                Lab_libel.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(1))
                Lab_prix_vente.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(2))
                Lab_prix_achat.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(3))
                Lab_qte_desp.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(4))


                ' Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "ID  trouvée"
                Admin.L_Notif.Text = "Confirmation"
                Btn_Supp.Enabled = True
                Btn_Annul.Enabled = True
            Else
                FLP_Vendeur.Hide()
                FLP_Produit.Hide()
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "ID non trouvée"
                Admin.L_Notif.Text = "Eurreur"
                Btn_Supp.Enabled = False
                Btn_Annul.Enabled = False
            End If
        End If


         


    End Sub

    Private Sub Supprimer_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(Admin.P_Notif)
        Admin.P_Notif.SetBounds(500, 10, 200, 79)

        FLP_Vendeur.Hide()
        FLP_Produit.Hide()
    End Sub

    Private Sub Btn_Supp_Click(sender As Object, e As EventArgs) Handles Btn_Supp.Click
        Admin.P_Notif.Show()


        If Admin.Titre.Text = Admin.Btn_Vendeur.Text Then
            Vendeur.DeleteQuery(txt_supp.Text)
            txt_supp.Text = ""
            Admin.P_Notif.Hide()
            FLP_Vendeur.Hide()
            FLP_Produit.Hide()
            Admin.P_Notif.Show()
            Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
            Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
            Admin.L_MSG.Text = "Supression réussite"
            Admin.L_Notif.Text = "Confirmation"
    

        Else
            Produit.DeleteQuery(txt_supp.Text)
            txt_supp.Text = ""
            Admin.P_Notif.Hide()
            FLP_Vendeur.Hide()
            FLP_Produit.Hide()
            Admin.P_Notif.Show()
            Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
            Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
            Admin.L_MSG.Text = "Supression réussite"
            Admin.L_Notif.Text = "Confirmation"

        End If


    End Sub

    Private Sub Btn_Annul_Click(sender As Object, e As EventArgs) Handles Btn_Annul.Click
        txt_supp.Text = ""
        Admin.P_Notif.Hide()
        FLP_Vendeur.Hide()
        FLP_Produit.Hide()
        Admin.P_Notif.Hide()

    End Sub

    Private Sub txt_supp_TextChanged(sender As Object, e As EventArgs) Handles txt_supp.TextChanged

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class