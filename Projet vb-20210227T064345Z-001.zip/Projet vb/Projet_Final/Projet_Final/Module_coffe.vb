﻿Module Module_coffe
    Public Vendeur As New DataSet_coffeTableAdapters.VENDEURTableAdapter
    Public Produit As New DataSet_coffeTableAdapters.PRODUITTableAdapter
    Public Facture As New DataSet_coffeTableAdapters.FACTURETableAdapter
    Public vente As New DataSet_coffeTableAdapters.VENTETableAdapter
    Public id_vc As String
    Public Seil As Integer = 10


    Public n As Integer = Vendeur.GetData.Rows.Count
    Public m As Integer = Produit.GetData.Rows.Count
    Public Str As String = "Connect"
    Public img As String = "C:\Users\Bayrem\Documents\Faculté\2_LFIG_5\Semester 2\SBDENDEV\Trabelsi Bayrem & Najjar Mohamed 2LFIG groupe 5\Projet_Final\img\"
    Public maj_min As Integer = 0
    Public iclavier As Integer = 0
    Public majus As Boolean
    Public num_fac As Integer = 0



  
End Module
