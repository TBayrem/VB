﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Connnect
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Connnect))
        Me.Btn_Clavier = New System.Windows.Forms.Button()
        Me.Panel_login = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.P_Eureur_P = New System.Windows.Forms.Panel()
        Me.P_Eureur_L = New System.Windows.Forms.Panel()
        Me.btn_Login = New System.Windows.Forms.Button()
        Me.Txt_Pass = New System.Windows.Forms.TextBox()
        Me.Txt_User = New System.Windows.Forms.TextBox()
        Me.Panel_login.SuspendLayout()
        Me.SuspendLayout()
        '
        'Btn_Clavier
        '
        Me.Btn_Clavier.Location = New System.Drawing.Point(326, 492)
        Me.Btn_Clavier.Name = "Btn_Clavier"
        Me.Btn_Clavier.Size = New System.Drawing.Size(165, 20)
        Me.Btn_Clavier.TabIndex = 0
        Me.Btn_Clavier.Text = "Clavier"
        Me.Btn_Clavier.UseVisualStyleBackColor = True
        '
        'Panel_login
        '
        Me.Panel_login.BackColor = System.Drawing.Color.LightGray
        Me.Panel_login.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel_login.Controls.Add(Me.Panel1)
        Me.Panel_login.Controls.Add(Me.P_Eureur_P)
        Me.Panel_login.Controls.Add(Me.P_Eureur_L)
        Me.Panel_login.Controls.Add(Me.btn_Login)
        Me.Panel_login.Controls.Add(Me.Txt_Pass)
        Me.Panel_login.Controls.Add(Me.Txt_User)
        Me.Panel_login.Location = New System.Drawing.Point(39, 39)
        Me.Panel_login.Name = "Panel_login"
        Me.Panel_login.Size = New System.Drawing.Size(232, 306)
        Me.Panel_login.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.Panel1.BackgroundImage = CType(resources.GetObject("Panel1.BackgroundImage"), System.Drawing.Image)
        Me.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Panel1.Location = New System.Drawing.Point(20, 17)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(188, 140)
        Me.Panel1.TabIndex = 5
        '
        'P_Eureur_P
        '
        Me.P_Eureur_P.BackColor = System.Drawing.Color.Transparent
        Me.P_Eureur_P.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.P_Eureur_P.Location = New System.Drawing.Point(162, 198)
        Me.P_Eureur_P.Name = "P_Eureur_P"
        Me.P_Eureur_P.Size = New System.Drawing.Size(20, 20)
        Me.P_Eureur_P.TabIndex = 4
        '
        'P_Eureur_L
        '
        Me.P_Eureur_L.BackColor = System.Drawing.Color.Transparent
        Me.P_Eureur_L.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.P_Eureur_L.Location = New System.Drawing.Point(162, 172)
        Me.P_Eureur_L.Name = "P_Eureur_L"
        Me.P_Eureur_L.Size = New System.Drawing.Size(20, 20)
        Me.P_Eureur_L.TabIndex = 3
        '
        'btn_Login
        '
        Me.btn_Login.BackColor = System.Drawing.Color.FromArgb(CType(CType(99, Byte), Integer), CType(CType(61, Byte), Integer), CType(CType(33, Byte), Integer))
        Me.btn_Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Login.Font = New System.Drawing.Font("Lucida Bright", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Login.ForeColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(30, Byte), Integer))
        Me.btn_Login.Location = New System.Drawing.Point(37, 232)
        Me.btn_Login.Name = "btn_Login"
        Me.btn_Login.Size = New System.Drawing.Size(157, 41)
        Me.btn_Login.TabIndex = 2
        Me.btn_Login.Text = "Log in"
        Me.btn_Login.UseVisualStyleBackColor = False
        '
        'Txt_Pass
        '
        Me.Txt_Pass.ForeColor = System.Drawing.Color.DarkGray
        Me.Txt_Pass.Location = New System.Drawing.Point(56, 198)
        Me.Txt_Pass.Name = "Txt_Pass"
        Me.Txt_Pass.Size = New System.Drawing.Size(100, 20)
        Me.Txt_Pass.TabIndex = 1
        Me.Txt_Pass.Text = "Password"
        '
        'Txt_User
        '
        Me.Txt_User.ForeColor = System.Drawing.Color.DarkGray
        Me.Txt_User.Location = New System.Drawing.Point(56, 172)
        Me.Txt_User.Name = "Txt_User"
        Me.Txt_User.Size = New System.Drawing.Size(100, 20)
        Me.Txt_User.TabIndex = 0
        Me.Txt_User.Text = "Username"
        '
        'Connnect
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(878, 512)
        Me.ControlBox = False
        Me.Controls.Add(Me.Panel_login)
        Me.Controls.Add(Me.Btn_Clavier)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Connnect"
        Me.ShowIcon = False
        Me.ShowInTaskbar = False
        Me.Text = "Connect"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel_login.ResumeLayout(False)
        Me.Panel_login.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Btn_Clavier As System.Windows.Forms.Button
    Friend WithEvents Panel_login As System.Windows.Forms.Panel
    Friend WithEvents btn_Login As System.Windows.Forms.Button
    Friend WithEvents Txt_Pass As System.Windows.Forms.TextBox
    Friend WithEvents Txt_User As System.Windows.Forms.TextBox
    Friend WithEvents P_Eureur_L As System.Windows.Forms.Panel
    Friend WithEvents P_Eureur_P As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel

End Class
