﻿Public Class Afficher

    Private Sub Afficher_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'TODO: cette ligne de code charge les données dans la table 'DataSet_coffe.PRODUIT'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        ' Me.PRODUITTableAdapter.Fill(Me.DataSet_coffe.PRODUIT)
        '  Produit_GV.SetBounds(5, 5, 515, 307)
        'TODO: cette ligne de code charge les données dans la table 'DataSet_coffe.VENDEUR'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        ' Me.VENDEURTableAdapter.Fill(Me.DataSet_coffe.VENDEUR)
        ' Vendeur_GV.SetBounds(5, 5, 544, 307)
    End Sub


End Class