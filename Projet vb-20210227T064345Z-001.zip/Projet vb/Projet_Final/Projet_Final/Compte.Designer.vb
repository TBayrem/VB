﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Compte
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Compte))
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Clavier = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.Black
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Location = New System.Drawing.Point(750, 12)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(50, 50)
        Me.Btn_Logout.TabIndex = 2
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Clavier
        '
        Me.Btn_Clavier.Location = New System.Drawing.Point(307, 333)
        Me.Btn_Clavier.Name = "Btn_Clavier"
        Me.Btn_Clavier.Size = New System.Drawing.Size(165, 20)
        Me.Btn_Clavier.TabIndex = 3
        Me.Btn_Clavier.Text = "Clavier"
        Me.Btn_Clavier.UseVisualStyleBackColor = True
        '
        'Compte
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(812, 436)
        Me.Controls.Add(Me.Btn_Clavier)
        Me.Controls.Add(Me.Btn_Logout)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Compte"
        Me.Text = "Compte"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Btn_Clavier As System.Windows.Forms.Button
End Class
