﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Ventesvb
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.GB_CAT = New System.Windows.Forms.GroupBox()
        Me.Btn_Pastries = New System.Windows.Forms.Button()
        Me.Btn_Smoothies = New System.Windows.Forms.Button()
        Me.Btn_Ice = New System.Windows.Forms.Button()
        Me.Btn_Hot = New System.Windows.Forms.Button()
        Me.FLP_Produit_V = New System.Windows.Forms.FlowLayoutPanel()
        Me.DataSet2 = New Projet_Final.DataSet2()
        Me.VENTEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VENTETableAdapter = New Projet_Final.DataSet2TableAdapters.VENTETableAdapter()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.btn_Supp_elem = New System.Windows.Forms.Button()
        Me.Totaux2 = New System.Windows.Forms.Label()
        Me.Bt_Annul = New System.Windows.Forms.Button()
        Me.Btn_Valider = New System.Windows.Forms.Button()
        Me.Totaux1 = New System.Windows.Forms.Label()
        Me.Date_Fac = New System.Windows.Forms.Label()
        Me.Num_Fac = New System.Windows.Forms.Label()
        Me.DGV_COMM = New System.Windows.Forms.DataGridView()
        Me.Qte_Desp = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Qte = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prod = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prix_UA = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prix_UV = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prix_A = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Prix_V = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.labf_totaux = New System.Windows.Forms.Label()
        Me.GB_CAT.SuspendLayout()
        CType(Me.DataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VENTEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.DGV_COMM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GB_CAT
        '
        Me.GB_CAT.Controls.Add(Me.Btn_Pastries)
        Me.GB_CAT.Controls.Add(Me.Btn_Smoothies)
        Me.GB_CAT.Controls.Add(Me.Btn_Ice)
        Me.GB_CAT.Controls.Add(Me.Btn_Hot)
        Me.GB_CAT.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GB_CAT.ForeColor = System.Drawing.SystemColors.ControlText
        Me.GB_CAT.Location = New System.Drawing.Point(12, 12)
        Me.GB_CAT.Name = "GB_CAT"
        Me.GB_CAT.Size = New System.Drawing.Size(502, 69)
        Me.GB_CAT.TabIndex = 0
        Me.GB_CAT.TabStop = False
        Me.GB_CAT.Text = "Catégorie du Produit"
        '
        'Btn_Pastries
        '
        Me.Btn_Pastries.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Pastries.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Pastries.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Btn_Pastries.Location = New System.Drawing.Point(378, 20)
        Me.Btn_Pastries.Name = "Btn_Pastries"
        Me.Btn_Pastries.Size = New System.Drawing.Size(118, 43)
        Me.Btn_Pastries.TabIndex = 3
        Me.Btn_Pastries.Text = "Pasteries"
        Me.Btn_Pastries.UseVisualStyleBackColor = True
        '
        'Btn_Smoothies
        '
        Me.Btn_Smoothies.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Smoothies.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Smoothies.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Btn_Smoothies.Location = New System.Drawing.Point(254, 20)
        Me.Btn_Smoothies.Name = "Btn_Smoothies"
        Me.Btn_Smoothies.Size = New System.Drawing.Size(118, 43)
        Me.Btn_Smoothies.TabIndex = 2
        Me.Btn_Smoothies.Text = "Smoothies"
        Me.Btn_Smoothies.UseVisualStyleBackColor = True
        '
        'Btn_Ice
        '
        Me.Btn_Ice.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Ice.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ice.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Btn_Ice.Location = New System.Drawing.Point(130, 20)
        Me.Btn_Ice.Name = "Btn_Ice"
        Me.Btn_Ice.Size = New System.Drawing.Size(118, 43)
        Me.Btn_Ice.TabIndex = 1
        Me.Btn_Ice.Text = "Ice_Drinks"
        Me.Btn_Ice.UseVisualStyleBackColor = True
        '
        'Btn_Hot
        '
        Me.Btn_Hot.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Hot.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Hot.Location = New System.Drawing.Point(6, 20)
        Me.Btn_Hot.Name = "Btn_Hot"
        Me.Btn_Hot.Size = New System.Drawing.Size(118, 43)
        Me.Btn_Hot.TabIndex = 0
        Me.Btn_Hot.Text = "Hot Drinks"
        Me.Btn_Hot.UseVisualStyleBackColor = True
        '
        'FLP_Produit_V
        '
        Me.FLP_Produit_V.AutoScroll = True
        Me.FLP_Produit_V.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FLP_Produit_V.ForeColor = System.Drawing.SystemColors.ControlText
        Me.FLP_Produit_V.Location = New System.Drawing.Point(12, 87)
        Me.FLP_Produit_V.Name = "FLP_Produit_V"
        Me.FLP_Produit_V.Size = New System.Drawing.Size(502, 290)
        Me.FLP_Produit_V.TabIndex = 1
        '
        'DataSet2
        '
        Me.DataSet2.DataSetName = "DataSet2"
        Me.DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VENTEBindingSource
        '
        Me.VENTEBindingSource.DataMember = "VENTE"
        Me.VENTEBindingSource.DataSource = Me.DataSet2
        '
        'VENTETableAdapter
        '
        Me.VENTETableAdapter.ClearBeforeFill = True
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.btn_Supp_elem)
        Me.Panel1.Controls.Add(Me.Totaux2)
        Me.Panel1.Controls.Add(Me.Bt_Annul)
        Me.Panel1.Controls.Add(Me.Btn_Valider)
        Me.Panel1.Controls.Add(Me.Totaux1)
        Me.Panel1.Controls.Add(Me.Date_Fac)
        Me.Panel1.Controls.Add(Me.Num_Fac)
        Me.Panel1.Controls.Add(Me.DGV_COMM)
        Me.Panel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Panel1.Location = New System.Drawing.Point(520, 12)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(452, 365)
        Me.Panel1.TabIndex = 2
        '
        'btn_Supp_elem
        '
        Me.btn_Supp_elem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.btn_Supp_elem.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btn_Supp_elem.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btn_Supp_elem.Location = New System.Drawing.Point(397, 316)
        Me.btn_Supp_elem.Name = "btn_Supp_elem"
        Me.btn_Supp_elem.Size = New System.Drawing.Size(43, 37)
        Me.btn_Supp_elem.TabIndex = 7
        Me.btn_Supp_elem.UseVisualStyleBackColor = True
        '
        'Totaux2
        '
        Me.Totaux2.AutoSize = True
        Me.Totaux2.Location = New System.Drawing.Point(12, 330)
        Me.Totaux2.Name = "Totaux2"
        Me.Totaux2.Size = New System.Drawing.Size(90, 13)
        Me.Totaux2.TabIndex = 6
        Me.Totaux2.Text = "Totaux d'achat   :"
        '
        'Bt_Annul
        '
        Me.Bt_Annul.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Bt_Annul.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Bt_Annul.Location = New System.Drawing.Point(313, 316)
        Me.Bt_Annul.Name = "Bt_Annul"
        Me.Bt_Annul.Size = New System.Drawing.Size(78, 37)
        Me.Bt_Annul.TabIndex = 5
        Me.Bt_Annul.Text = "Annuler"
        Me.Bt_Annul.UseVisualStyleBackColor = True
        '
        'Btn_Valider
        '
        Me.Btn_Valider.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Valider.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Valider.Location = New System.Drawing.Point(224, 316)
        Me.Btn_Valider.Name = "Btn_Valider"
        Me.Btn_Valider.Size = New System.Drawing.Size(83, 37)
        Me.Btn_Valider.TabIndex = 4
        Me.Btn_Valider.Text = "Valider"
        Me.Btn_Valider.UseVisualStyleBackColor = True
        '
        'Totaux1
        '
        Me.Totaux1.AutoSize = True
        Me.Totaux1.Location = New System.Drawing.Point(12, 316)
        Me.Totaux1.Name = "Totaux1"
        Me.Totaux1.Size = New System.Drawing.Size(91, 13)
        Me.Totaux1.TabIndex = 3
        Me.Totaux1.Text = "Totaux de vente :"
        '
        'Date_Fac
        '
        Me.Date_Fac.AutoSize = True
        Me.Date_Fac.Location = New System.Drawing.Point(336, 11)
        Me.Date_Fac.Name = "Date_Fac"
        Me.Date_Fac.Size = New System.Drawing.Size(21, 13)
        Me.Date_Fac.TabIndex = 2
        Me.Date_Fac.Text = "le :"
        '
        'Num_Fac
        '
        Me.Num_Fac.AutoSize = True
        Me.Num_Fac.Location = New System.Drawing.Point(21, 26)
        Me.Num_Fac.Name = "Num_Fac"
        Me.Num_Fac.Size = New System.Drawing.Size(22, 13)
        Me.Num_Fac.TabIndex = 1
        Me.Num_Fac.Text = "N°:"
        '
        'DGV_COMM
        '
        Me.DGV_COMM.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV_COMM.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Qte_Desp, Me.Qte, Me.Prod, Me.Prix_UA, Me.Prix_UV, Me.Prix_A, Me.Prix_V})
        Me.DGV_COMM.Location = New System.Drawing.Point(15, 42)
        Me.DGV_COMM.Name = "DGV_COMM"
        Me.DGV_COMM.ReadOnly = True
        Me.DGV_COMM.Size = New System.Drawing.Size(425, 260)
        Me.DGV_COMM.TabIndex = 0
        '
        'Qte_Desp
        '
        Me.Qte_Desp.HeaderText = "Qte. desp."
        Me.Qte_Desp.Name = "Qte_Desp"
        Me.Qte_Desp.ReadOnly = True
        Me.Qte_Desp.Width = 50
        '
        'Qte
        '
        Me.Qte.HeaderText = "Qte"
        Me.Qte.Name = "Qte"
        Me.Qte.ReadOnly = True
        Me.Qte.Width = 50
        '
        'Prod
        '
        Me.Prod.HeaderText = "Produit"
        Me.Prod.Name = "Prod"
        Me.Prod.ReadOnly = True
        Me.Prod.Width = 80
        '
        'Prix_UA
        '
        Me.Prix_UA.HeaderText = "Prix U.A."
        Me.Prix_UA.Name = "Prix_UA"
        Me.Prix_UA.ReadOnly = True
        Me.Prix_UA.Width = 50
        '
        'Prix_UV
        '
        Me.Prix_UV.HeaderText = "Prix U.V."
        Me.Prix_UV.Name = "Prix_UV"
        Me.Prix_UV.ReadOnly = True
        Me.Prix_UV.Width = 50
        '
        'Prix_A
        '
        Me.Prix_A.HeaderText = "Prix Achat"
        Me.Prix_A.Name = "Prix_A"
        Me.Prix_A.ReadOnly = True
        Me.Prix_A.Width = 50
        '
        'Prix_V
        '
        Me.Prix_V.HeaderText = "Prix Vente"
        Me.Prix_V.Name = "Prix_V"
        Me.Prix_V.ReadOnly = True
        Me.Prix_V.Width = 50
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(16, 47)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(335, 260)
        Me.DataGridView1.TabIndex = 0
        '
        'labf_totaux
        '
        Me.labf_totaux.AutoSize = True
        Me.labf_totaux.Location = New System.Drawing.Point(12, 343)
        Me.labf_totaux.Name = "labf_totaux"
        Me.labf_totaux.Size = New System.Drawing.Size(39, 13)
        Me.labf_totaux.TabIndex = 3
        Me.labf_totaux.Text = "Label3"
        '
        'Ventesvb
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(989, 401)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.FLP_Produit_V)
        Me.Controls.Add(Me.GB_CAT)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Ventesvb"
        Me.Opacity = 0.9R
        Me.Text = "Ventesvb"
        Me.GB_CAT.ResumeLayout(False)
        CType(Me.DataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VENTEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.DGV_COMM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GB_CAT As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_Pastries As System.Windows.Forms.Button
    Friend WithEvents Btn_Smoothies As System.Windows.Forms.Button
    Friend WithEvents Btn_Ice As System.Windows.Forms.Button
    Friend WithEvents Btn_Hot As System.Windows.Forms.Button
    Friend WithEvents FLP_Produit_V As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents COMMANDEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VENTEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents DGV_COMM As System.Windows.Forms.DataGridView
    Friend WithEvents Totaux1 As System.Windows.Forms.Label
    Friend WithEvents Date_Fac As System.Windows.Forms.Label
    Friend WithEvents Num_Fac As System.Windows.Forms.Label
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents labf_totaux As System.Windows.Forms.Label

    Friend WithEvents DataSet2 As Projet_Final.DataSet2

    Friend WithEvents VENTETableAdapter As Projet_Final.DataSet2TableAdapters.VENTETableAdapter
    Friend WithEvents Bt_Annul As System.Windows.Forms.Button
    Friend WithEvents Btn_Valider As System.Windows.Forms.Button
    Friend WithEvents Totaux2 As System.Windows.Forms.Label
    Friend WithEvents Qte_Desp As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qte As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Prod As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Prix_UA As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Prix_UV As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Prix_A As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Prix_V As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents btn_Supp_elem As System.Windows.Forms.Button
End Class
