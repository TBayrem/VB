﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Clavier
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Clavier))
        Me.N0 = New System.Windows.Forms.Button()
        Me.egale = New System.Windows.Forms.Button()
        Me.plus = New System.Windows.Forms.Button()
        Me.moins = New System.Windows.Forms.Button()
        Me.etoile = New System.Windows.Forms.Button()
        Me.sur = New System.Windows.Forms.Button()
        Me.N1 = New System.Windows.Forms.Button()
        Me.N2 = New System.Windows.Forms.Button()
        Me.N3 = New System.Windows.Forms.Button()
        Me.N8 = New System.Windows.Forms.Button()
        Me.N7 = New System.Windows.Forms.Button()
        Me.N5 = New System.Windows.Forms.Button()
        Me.N9 = New System.Windows.Forms.Button()
        Me.N4 = New System.Windows.Forms.Button()
        Me.N6 = New System.Windows.Forms.Button()
        Me.à = New System.Windows.Forms.Button()
        Me.ç = New System.Windows.Forms.Button()
        Me.ù = New System.Windows.Forms.Button()
        Me.è = New System.Windows.Forms.Button()
        Me.é = New System.Windows.Forms.Button()
        Me.arou = New System.Windows.Forms.Button()
        Me.A = New System.Windows.Forms.Button()
        Me.B = New System.Windows.Forms.Button()
        Me.V = New System.Windows.Forms.Button()
        Me.C = New System.Windows.Forms.Button()
        Me.X = New System.Windows.Forms.Button()
        Me.L = New System.Windows.Forms.Button()
        Me.W = New System.Windows.Forms.Button()
        Me.K = New System.Windows.Forms.Button()
        Me.J = New System.Windows.Forms.Button()
        Me.H = New System.Windows.Forms.Button()
        Me.G = New System.Windows.Forms.Button()
        Me.F = New System.Windows.Forms.Button()
        Me.D = New System.Windows.Forms.Button()
        Me.S = New System.Windows.Forms.Button()
        Me.Q = New System.Windows.Forms.Button()
        Me.P = New System.Windows.Forms.Button()
        Me.O = New System.Windows.Forms.Button()
        Me.I = New System.Windows.Forms.Button()
        Me.Y = New System.Windows.Forms.Button()
        Me.T = New System.Windows.Forms.Button()
        Me.R = New System.Windows.Forms.Button()
        Me.E = New System.Windows.Forms.Button()
        Me.Z = New System.Windows.Forms.Button()
        Me.Maj = New System.Windows.Forms.Button()
        Me.ex_in = New System.Windows.Forms.Button()
        Me.pt = New System.Windows.Forms.Button()
        Me.espace = New System.Windows.Forms.Button()
        Me.M = New System.Windows.Forms.Button()
        Me.pv = New System.Windows.Forms.Button()
        Me.pt2 = New System.Windows.Forms.Button()
        Me.N = New System.Windows.Forms.Button()
        Me.virg = New System.Windows.Forms.Button()
        Me.U = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'N0
        '
        Me.N0.BackgroundImage = CType(resources.GetObject("N0.BackgroundImage"), System.Drawing.Image)
        Me.N0.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N0.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N0.ForeColor = System.Drawing.Color.White
        Me.N0.Location = New System.Drawing.Point(407, 111)
        Me.N0.Name = "N0"
        Me.N0.Size = New System.Drawing.Size(73, 36)
        Me.N0.TabIndex = 210
        Me.N0.Text = "0"
        Me.N0.UseVisualStyleBackColor = True
        '
        'egale
        '
        Me.egale.BackgroundImage = CType(resources.GetObject("egale.BackgroundImage"), System.Drawing.Image)
        Me.egale.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.egale.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.egale.ForeColor = System.Drawing.Color.White
        Me.egale.Location = New System.Drawing.Point(475, 111)
        Me.egale.Name = "egale"
        Me.egale.Size = New System.Drawing.Size(39, 36)
        Me.egale.TabIndex = 209
        Me.egale.Text = "="
        Me.egale.UseVisualStyleBackColor = True
        '
        'plus
        '
        Me.plus.BackgroundImage = CType(resources.GetObject("plus.BackgroundImage"), System.Drawing.Image)
        Me.plus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.plus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.plus.ForeColor = System.Drawing.Color.White
        Me.plus.Location = New System.Drawing.Point(509, 111)
        Me.plus.Name = "plus"
        Me.plus.Size = New System.Drawing.Size(39, 36)
        Me.plus.TabIndex = 208
        Me.plus.Text = "+"
        Me.plus.UseVisualStyleBackColor = True
        '
        'moins
        '
        Me.moins.BackgroundImage = CType(resources.GetObject("moins.BackgroundImage"), System.Drawing.Image)
        Me.moins.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.moins.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.moins.ForeColor = System.Drawing.Color.White
        Me.moins.Location = New System.Drawing.Point(509, 78)
        Me.moins.Name = "moins"
        Me.moins.Size = New System.Drawing.Size(39, 36)
        Me.moins.TabIndex = 207
        Me.moins.Text = "-"
        Me.moins.UseVisualStyleBackColor = True
        '
        'etoile
        '
        Me.etoile.BackgroundImage = CType(resources.GetObject("etoile.BackgroundImage"), System.Drawing.Image)
        Me.etoile.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.etoile.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.etoile.ForeColor = System.Drawing.Color.White
        Me.etoile.Location = New System.Drawing.Point(509, 45)
        Me.etoile.Name = "etoile"
        Me.etoile.Size = New System.Drawing.Size(39, 36)
        Me.etoile.TabIndex = 206
        Me.etoile.Text = "*"
        Me.etoile.UseVisualStyleBackColor = True
        '
        'sur
        '
        Me.sur.BackgroundImage = CType(resources.GetObject("sur.BackgroundImage"), System.Drawing.Image)
        Me.sur.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.sur.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.sur.ForeColor = System.Drawing.Color.White
        Me.sur.Location = New System.Drawing.Point(509, 12)
        Me.sur.Name = "sur"
        Me.sur.Size = New System.Drawing.Size(39, 36)
        Me.sur.TabIndex = 205
        Me.sur.Text = "/"
        Me.sur.UseVisualStyleBackColor = True
        '
        'N1
        '
        Me.N1.BackgroundImage = CType(resources.GetObject("N1.BackgroundImage"), System.Drawing.Image)
        Me.N1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N1.ForeColor = System.Drawing.Color.White
        Me.N1.Location = New System.Drawing.Point(407, 78)
        Me.N1.Name = "N1"
        Me.N1.Size = New System.Drawing.Size(39, 36)
        Me.N1.TabIndex = 204
        Me.N1.Text = "1"
        Me.N1.UseVisualStyleBackColor = True
        '
        'N2
        '
        Me.N2.BackgroundImage = CType(resources.GetObject("N2.BackgroundImage"), System.Drawing.Image)
        Me.N2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N2.ForeColor = System.Drawing.Color.White
        Me.N2.Location = New System.Drawing.Point(441, 78)
        Me.N2.Name = "N2"
        Me.N2.Size = New System.Drawing.Size(39, 36)
        Me.N2.TabIndex = 203
        Me.N2.Text = "2"
        Me.N2.UseVisualStyleBackColor = True
        '
        'N3
        '
        Me.N3.BackgroundImage = CType(resources.GetObject("N3.BackgroundImage"), System.Drawing.Image)
        Me.N3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N3.ForeColor = System.Drawing.Color.White
        Me.N3.Location = New System.Drawing.Point(475, 78)
        Me.N3.Name = "N3"
        Me.N3.Size = New System.Drawing.Size(39, 36)
        Me.N3.TabIndex = 202
        Me.N3.Text = "3"
        Me.N3.UseVisualStyleBackColor = True
        '
        'N8
        '
        Me.N8.BackgroundImage = CType(resources.GetObject("N8.BackgroundImage"), System.Drawing.Image)
        Me.N8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N8.ForeColor = System.Drawing.Color.White
        Me.N8.Location = New System.Drawing.Point(441, 12)
        Me.N8.Name = "N8"
        Me.N8.Size = New System.Drawing.Size(39, 36)
        Me.N8.TabIndex = 201
        Me.N8.Text = "8"
        Me.N8.UseVisualStyleBackColor = True
        '
        'N7
        '
        Me.N7.BackgroundImage = CType(resources.GetObject("N7.BackgroundImage"), System.Drawing.Image)
        Me.N7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N7.ForeColor = System.Drawing.Color.White
        Me.N7.Location = New System.Drawing.Point(407, 12)
        Me.N7.Name = "N7"
        Me.N7.Size = New System.Drawing.Size(39, 36)
        Me.N7.TabIndex = 200
        Me.N7.Text = "7"
        Me.N7.UseVisualStyleBackColor = True
        '
        'N5
        '
        Me.N5.BackgroundImage = CType(resources.GetObject("N5.BackgroundImage"), System.Drawing.Image)
        Me.N5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N5.ForeColor = System.Drawing.Color.White
        Me.N5.Location = New System.Drawing.Point(441, 45)
        Me.N5.Name = "N5"
        Me.N5.Size = New System.Drawing.Size(39, 36)
        Me.N5.TabIndex = 199
        Me.N5.Text = "5"
        Me.N5.UseVisualStyleBackColor = True
        '
        'N9
        '
        Me.N9.BackgroundImage = CType(resources.GetObject("N9.BackgroundImage"), System.Drawing.Image)
        Me.N9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N9.ForeColor = System.Drawing.Color.White
        Me.N9.Location = New System.Drawing.Point(475, 12)
        Me.N9.Name = "N9"
        Me.N9.Size = New System.Drawing.Size(39, 36)
        Me.N9.TabIndex = 198
        Me.N9.Text = "9"
        Me.N9.UseVisualStyleBackColor = True
        '
        'N4
        '
        Me.N4.BackgroundImage = CType(resources.GetObject("N4.BackgroundImage"), System.Drawing.Image)
        Me.N4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N4.ForeColor = System.Drawing.Color.White
        Me.N4.Location = New System.Drawing.Point(407, 45)
        Me.N4.Name = "N4"
        Me.N4.Size = New System.Drawing.Size(39, 36)
        Me.N4.TabIndex = 197
        Me.N4.Text = "4"
        Me.N4.UseVisualStyleBackColor = True
        '
        'N6
        '
        Me.N6.BackgroundImage = CType(resources.GetObject("N6.BackgroundImage"), System.Drawing.Image)
        Me.N6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N6.ForeColor = System.Drawing.Color.White
        Me.N6.Location = New System.Drawing.Point(475, 45)
        Me.N6.Name = "N6"
        Me.N6.Size = New System.Drawing.Size(39, 36)
        Me.N6.TabIndex = 196
        Me.N6.Text = "6"
        Me.N6.UseVisualStyleBackColor = True
        '
        'à
        '
        Me.à.BackgroundImage = CType(resources.GetObject("à.BackgroundImage"), System.Drawing.Image)
        Me.à.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.à.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.à.ForeColor = System.Drawing.Color.White
        Me.à.Location = New System.Drawing.Point(287, 111)
        Me.à.Name = "à"
        Me.à.Size = New System.Drawing.Size(39, 36)
        Me.à.TabIndex = 195
        Me.à.Text = "à"
        Me.à.UseVisualStyleBackColor = True
        '
        'ç
        '
        Me.ç.BackgroundImage = CType(resources.GetObject("ç.BackgroundImage"), System.Drawing.Image)
        Me.ç.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ç.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ç.ForeColor = System.Drawing.Color.White
        Me.ç.Location = New System.Drawing.Point(321, 111)
        Me.ç.Name = "ç"
        Me.ç.Size = New System.Drawing.Size(39, 36)
        Me.ç.TabIndex = 194
        Me.ç.Text = "ç"
        Me.ç.UseVisualStyleBackColor = True
        '
        'ù
        '
        Me.ù.BackgroundImage = CType(resources.GetObject("ù.BackgroundImage"), System.Drawing.Image)
        Me.ù.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ù.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ù.ForeColor = System.Drawing.Color.White
        Me.ù.Location = New System.Drawing.Point(355, 111)
        Me.ù.Name = "ù"
        Me.ù.Size = New System.Drawing.Size(39, 36)
        Me.ù.TabIndex = 193
        Me.ù.Text = "ù"
        Me.ù.UseVisualStyleBackColor = True
        '
        'è
        '
        Me.è.BackgroundImage = CType(resources.GetObject("è.BackgroundImage"), System.Drawing.Image)
        Me.è.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.è.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.è.ForeColor = System.Drawing.Color.White
        Me.è.Location = New System.Drawing.Point(83, 111)
        Me.è.Name = "è"
        Me.è.Size = New System.Drawing.Size(39, 36)
        Me.è.TabIndex = 192
        Me.è.Text = "è"
        Me.è.UseVisualStyleBackColor = True
        '
        'é
        '
        Me.é.BackgroundImage = CType(resources.GetObject("é.BackgroundImage"), System.Drawing.Image)
        Me.é.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.é.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.é.ForeColor = System.Drawing.Color.White
        Me.é.Location = New System.Drawing.Point(47, 111)
        Me.é.Name = "é"
        Me.é.Size = New System.Drawing.Size(39, 36)
        Me.é.TabIndex = 191
        Me.é.Text = "é"
        Me.é.UseVisualStyleBackColor = True
        '
        'arou
        '
        Me.arou.BackgroundImage = CType(resources.GetObject("arou.BackgroundImage"), System.Drawing.Image)
        Me.arou.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.arou.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.arou.ForeColor = System.Drawing.Color.White
        Me.arou.Location = New System.Drawing.Point(3, 12)
        Me.arou.Name = "arou"
        Me.arou.Size = New System.Drawing.Size(49, 36)
        Me.arou.TabIndex = 190
        Me.arou.Text = "@"
        Me.arou.UseVisualStyleBackColor = True
        '
        'A
        '
        Me.A.BackgroundImage = CType(resources.GetObject("A.BackgroundImage"), System.Drawing.Image)
        Me.A.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.A.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.A.ForeColor = System.Drawing.Color.White
        Me.A.Location = New System.Drawing.Point(47, 12)
        Me.A.Name = "A"
        Me.A.Size = New System.Drawing.Size(39, 36)
        Me.A.TabIndex = 189
        Me.A.Text = "A"
        Me.A.UseVisualStyleBackColor = True
        '
        'B
        '
        Me.B.BackgroundImage = CType(resources.GetObject("B.BackgroundImage"), System.Drawing.Image)
        Me.B.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.B.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.B.ForeColor = System.Drawing.Color.White
        Me.B.Location = New System.Drawing.Point(185, 78)
        Me.B.Name = "B"
        Me.B.Size = New System.Drawing.Size(39, 36)
        Me.B.TabIndex = 188
        Me.B.Text = "B"
        Me.B.UseVisualStyleBackColor = True
        '
        'V
        '
        Me.V.BackgroundImage = CType(resources.GetObject("V.BackgroundImage"), System.Drawing.Image)
        Me.V.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.V.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.V.ForeColor = System.Drawing.Color.White
        Me.V.Location = New System.Drawing.Point(151, 78)
        Me.V.Name = "V"
        Me.V.Size = New System.Drawing.Size(39, 36)
        Me.V.TabIndex = 187
        Me.V.Text = "V"
        Me.V.UseVisualStyleBackColor = True
        '
        'C
        '
        Me.C.BackgroundImage = CType(resources.GetObject("C.BackgroundImage"), System.Drawing.Image)
        Me.C.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.C.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.C.ForeColor = System.Drawing.Color.White
        Me.C.Location = New System.Drawing.Point(117, 78)
        Me.C.Name = "C"
        Me.C.Size = New System.Drawing.Size(39, 36)
        Me.C.TabIndex = 186
        Me.C.Text = "C"
        Me.C.UseVisualStyleBackColor = True
        '
        'X
        '
        Me.X.BackgroundImage = CType(resources.GetObject("X.BackgroundImage"), System.Drawing.Image)
        Me.X.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.X.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.X.ForeColor = System.Drawing.Color.White
        Me.X.Location = New System.Drawing.Point(83, 78)
        Me.X.Name = "X"
        Me.X.Size = New System.Drawing.Size(39, 36)
        Me.X.TabIndex = 185
        Me.X.Text = "X"
        Me.X.UseVisualStyleBackColor = True
        '
        'L
        '
        Me.L.BackgroundImage = CType(resources.GetObject("L.BackgroundImage"), System.Drawing.Image)
        Me.L.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.L.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.L.ForeColor = System.Drawing.Color.White
        Me.L.Location = New System.Drawing.Point(321, 45)
        Me.L.Name = "L"
        Me.L.Size = New System.Drawing.Size(39, 36)
        Me.L.TabIndex = 184
        Me.L.Text = "L"
        Me.L.UseVisualStyleBackColor = True
        '
        'W
        '
        Me.W.BackgroundImage = CType(resources.GetObject("W.BackgroundImage"), System.Drawing.Image)
        Me.W.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.W.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.W.ForeColor = System.Drawing.Color.White
        Me.W.Location = New System.Drawing.Point(47, 78)
        Me.W.Name = "W"
        Me.W.Size = New System.Drawing.Size(39, 36)
        Me.W.TabIndex = 183
        Me.W.Text = "W"
        Me.W.UseVisualStyleBackColor = True
        '
        'K
        '
        Me.K.BackgroundImage = CType(resources.GetObject("K.BackgroundImage"), System.Drawing.Image)
        Me.K.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.K.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.K.ForeColor = System.Drawing.Color.White
        Me.K.Location = New System.Drawing.Point(287, 45)
        Me.K.Name = "K"
        Me.K.Size = New System.Drawing.Size(39, 36)
        Me.K.TabIndex = 182
        Me.K.Text = "K"
        Me.K.UseVisualStyleBackColor = True
        '
        'J
        '
        Me.J.BackgroundImage = CType(resources.GetObject("J.BackgroundImage"), System.Drawing.Image)
        Me.J.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.J.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.J.ForeColor = System.Drawing.Color.White
        Me.J.Location = New System.Drawing.Point(253, 45)
        Me.J.Name = "J"
        Me.J.Size = New System.Drawing.Size(39, 36)
        Me.J.TabIndex = 181
        Me.J.Text = "J"
        Me.J.UseVisualStyleBackColor = True
        '
        'H
        '
        Me.H.BackgroundImage = CType(resources.GetObject("H.BackgroundImage"), System.Drawing.Image)
        Me.H.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.H.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.H.ForeColor = System.Drawing.Color.White
        Me.H.Location = New System.Drawing.Point(219, 45)
        Me.H.Name = "H"
        Me.H.Size = New System.Drawing.Size(39, 36)
        Me.H.TabIndex = 180
        Me.H.Text = "H"
        Me.H.UseVisualStyleBackColor = True
        '
        'G
        '
        Me.G.BackgroundImage = CType(resources.GetObject("G.BackgroundImage"), System.Drawing.Image)
        Me.G.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.G.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.G.ForeColor = System.Drawing.Color.White
        Me.G.Location = New System.Drawing.Point(185, 45)
        Me.G.Name = "G"
        Me.G.Size = New System.Drawing.Size(39, 36)
        Me.G.TabIndex = 179
        Me.G.Text = "G"
        Me.G.UseVisualStyleBackColor = True
        '
        'F
        '
        Me.F.BackgroundImage = CType(resources.GetObject("F.BackgroundImage"), System.Drawing.Image)
        Me.F.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.F.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.F.ForeColor = System.Drawing.Color.White
        Me.F.Location = New System.Drawing.Point(151, 45)
        Me.F.Name = "F"
        Me.F.Size = New System.Drawing.Size(39, 36)
        Me.F.TabIndex = 178
        Me.F.Text = "F"
        Me.F.UseVisualStyleBackColor = True
        '
        'D
        '
        Me.D.BackgroundImage = CType(resources.GetObject("D.BackgroundImage"), System.Drawing.Image)
        Me.D.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.D.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.D.ForeColor = System.Drawing.Color.White
        Me.D.Location = New System.Drawing.Point(117, 45)
        Me.D.Name = "D"
        Me.D.Size = New System.Drawing.Size(39, 36)
        Me.D.TabIndex = 177
        Me.D.Text = "D"
        Me.D.UseVisualStyleBackColor = True
        '
        'S
        '
        Me.S.BackgroundImage = CType(resources.GetObject("S.BackgroundImage"), System.Drawing.Image)
        Me.S.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.S.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.S.ForeColor = System.Drawing.Color.White
        Me.S.Location = New System.Drawing.Point(83, 45)
        Me.S.Name = "S"
        Me.S.Size = New System.Drawing.Size(39, 36)
        Me.S.TabIndex = 176
        Me.S.Text = "S"
        Me.S.UseVisualStyleBackColor = True
        '
        'Q
        '
        Me.Q.BackgroundImage = CType(resources.GetObject("Q.BackgroundImage"), System.Drawing.Image)
        Me.Q.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Q.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Q.ForeColor = System.Drawing.Color.White
        Me.Q.Location = New System.Drawing.Point(47, 45)
        Me.Q.Name = "Q"
        Me.Q.Size = New System.Drawing.Size(39, 36)
        Me.Q.TabIndex = 175
        Me.Q.Text = "Q"
        Me.Q.UseVisualStyleBackColor = True
        '
        'P
        '
        Me.P.BackgroundImage = CType(resources.GetObject("P.BackgroundImage"), System.Drawing.Image)
        Me.P.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.P.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.P.ForeColor = System.Drawing.Color.White
        Me.P.Location = New System.Drawing.Point(355, 12)
        Me.P.Name = "P"
        Me.P.Size = New System.Drawing.Size(39, 36)
        Me.P.TabIndex = 174
        Me.P.Text = "P"
        Me.P.UseVisualStyleBackColor = True
        '
        'O
        '
        Me.O.BackgroundImage = CType(resources.GetObject("O.BackgroundImage"), System.Drawing.Image)
        Me.O.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.O.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.O.ForeColor = System.Drawing.Color.White
        Me.O.Location = New System.Drawing.Point(321, 12)
        Me.O.Name = "O"
        Me.O.Size = New System.Drawing.Size(39, 36)
        Me.O.TabIndex = 173
        Me.O.Text = "O"
        Me.O.UseVisualStyleBackColor = True
        '
        'I
        '
        Me.I.BackgroundImage = CType(resources.GetObject("I.BackgroundImage"), System.Drawing.Image)
        Me.I.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.I.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.I.ForeColor = System.Drawing.Color.White
        Me.I.Location = New System.Drawing.Point(287, 12)
        Me.I.Name = "I"
        Me.I.Size = New System.Drawing.Size(39, 36)
        Me.I.TabIndex = 172
        Me.I.Text = "I"
        Me.I.UseVisualStyleBackColor = True
        '
        'Y
        '
        Me.Y.BackgroundImage = CType(resources.GetObject("Y.BackgroundImage"), System.Drawing.Image)
        Me.Y.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Y.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Y.ForeColor = System.Drawing.Color.White
        Me.Y.Location = New System.Drawing.Point(219, 12)
        Me.Y.Name = "Y"
        Me.Y.Size = New System.Drawing.Size(39, 36)
        Me.Y.TabIndex = 171
        Me.Y.Text = "Y"
        Me.Y.UseVisualStyleBackColor = True
        '
        'T
        '
        Me.T.BackgroundImage = CType(resources.GetObject("T.BackgroundImage"), System.Drawing.Image)
        Me.T.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.T.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.T.ForeColor = System.Drawing.Color.White
        Me.T.Location = New System.Drawing.Point(185, 12)
        Me.T.Name = "T"
        Me.T.Size = New System.Drawing.Size(39, 36)
        Me.T.TabIndex = 170
        Me.T.Text = "T"
        Me.T.UseVisualStyleBackColor = True
        '
        'R
        '
        Me.R.BackgroundImage = CType(resources.GetObject("R.BackgroundImage"), System.Drawing.Image)
        Me.R.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.R.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.R.ForeColor = System.Drawing.Color.White
        Me.R.Location = New System.Drawing.Point(151, 12)
        Me.R.Name = "R"
        Me.R.Size = New System.Drawing.Size(39, 36)
        Me.R.TabIndex = 169
        Me.R.Text = "R"
        Me.R.UseVisualStyleBackColor = True
        '
        'E
        '
        Me.E.BackgroundImage = CType(resources.GetObject("E.BackgroundImage"), System.Drawing.Image)
        Me.E.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.E.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.E.ForeColor = System.Drawing.Color.White
        Me.E.Location = New System.Drawing.Point(117, 12)
        Me.E.Name = "E"
        Me.E.Size = New System.Drawing.Size(39, 36)
        Me.E.TabIndex = 168
        Me.E.Text = "E"
        Me.E.UseVisualStyleBackColor = True
        '
        'Z
        '
        Me.Z.BackgroundImage = CType(resources.GetObject("Z.BackgroundImage"), System.Drawing.Image)
        Me.Z.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Z.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Z.ForeColor = System.Drawing.Color.White
        Me.Z.Location = New System.Drawing.Point(83, 12)
        Me.Z.Name = "Z"
        Me.Z.Size = New System.Drawing.Size(39, 36)
        Me.Z.TabIndex = 167
        Me.Z.Text = "Z"
        Me.Z.UseVisualStyleBackColor = True
        '
        'Maj
        '
        Me.Maj.BackgroundImage = CType(resources.GetObject("Maj.BackgroundImage"), System.Drawing.Image)
        Me.Maj.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Maj.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Maj.ForeColor = System.Drawing.Color.White
        Me.Maj.Location = New System.Drawing.Point(3, 45)
        Me.Maj.Name = "Maj"
        Me.Maj.Size = New System.Drawing.Size(49, 69)
        Me.Maj.TabIndex = 165
        Me.Maj.Text = "Maj Min"
        Me.Maj.UseVisualStyleBackColor = True
        '
        'ex_in
        '
        Me.ex_in.BackgroundImage = CType(resources.GetObject("ex_in.BackgroundImage"), System.Drawing.Image)
        Me.ex_in.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ex_in.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.ex_in.ForeColor = System.Drawing.Color.White
        Me.ex_in.Location = New System.Drawing.Point(3, 111)
        Me.ex_in.Name = "ex_in"
        Me.ex_in.Size = New System.Drawing.Size(49, 36)
        Me.ex_in.TabIndex = 164
        Me.ex_in.Text = "!/?"
        Me.ex_in.UseVisualStyleBackColor = True
        '
        'pt
        '
        Me.pt.BackgroundImage = CType(resources.GetObject("pt.BackgroundImage"), System.Drawing.Image)
        Me.pt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pt.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.pt.ForeColor = System.Drawing.Color.White
        Me.pt.Location = New System.Drawing.Point(321, 78)
        Me.pt.Name = "pt"
        Me.pt.Size = New System.Drawing.Size(39, 36)
        Me.pt.TabIndex = 163
        Me.pt.Text = "."
        Me.pt.UseVisualStyleBackColor = True
        '
        'espace
        '
        Me.espace.BackgroundImage = CType(resources.GetObject("espace.BackgroundImage"), System.Drawing.Image)
        Me.espace.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.espace.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.espace.ForeColor = System.Drawing.Color.White
        Me.espace.Location = New System.Drawing.Point(118, 111)
        Me.espace.Name = "espace"
        Me.espace.Size = New System.Drawing.Size(174, 36)
        Me.espace.TabIndex = 162
        Me.espace.Text = "|________________|"
        Me.espace.UseVisualStyleBackColor = True
        '
        'M
        '
        Me.M.BackgroundImage = CType(resources.GetObject("M.BackgroundImage"), System.Drawing.Image)
        Me.M.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.M.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.M.ForeColor = System.Drawing.Color.White
        Me.M.Location = New System.Drawing.Point(355, 45)
        Me.M.Name = "M"
        Me.M.Size = New System.Drawing.Size(39, 36)
        Me.M.TabIndex = 159
        Me.M.Text = "M"
        Me.M.UseVisualStyleBackColor = True
        '
        'pv
        '
        Me.pv.BackgroundImage = CType(resources.GetObject("pv.BackgroundImage"), System.Drawing.Image)
        Me.pv.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pv.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.pv.ForeColor = System.Drawing.Color.White
        Me.pv.Location = New System.Drawing.Point(287, 78)
        Me.pv.Name = "pv"
        Me.pv.Size = New System.Drawing.Size(39, 36)
        Me.pv.TabIndex = 158
        Me.pv.Text = ";"
        Me.pv.UseVisualStyleBackColor = True
        '
        'pt2
        '
        Me.pt2.BackgroundImage = CType(resources.GetObject("pt2.BackgroundImage"), System.Drawing.Image)
        Me.pt2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.pt2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.pt2.ForeColor = System.Drawing.Color.White
        Me.pt2.Location = New System.Drawing.Point(355, 78)
        Me.pt2.Name = "pt2"
        Me.pt2.Size = New System.Drawing.Size(39, 36)
        Me.pt2.TabIndex = 157
        Me.pt2.Text = ":"
        Me.pt2.UseVisualStyleBackColor = True
        '
        'N
        '
        Me.N.BackgroundImage = CType(resources.GetObject("N.BackgroundImage"), System.Drawing.Image)
        Me.N.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.N.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.N.ForeColor = System.Drawing.Color.White
        Me.N.Location = New System.Drawing.Point(219, 78)
        Me.N.Name = "N"
        Me.N.Size = New System.Drawing.Size(39, 36)
        Me.N.TabIndex = 156
        Me.N.Text = "N"
        Me.N.UseVisualStyleBackColor = True
        '
        'virg
        '
        Me.virg.BackgroundImage = CType(resources.GetObject("virg.BackgroundImage"), System.Drawing.Image)
        Me.virg.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.virg.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.virg.ForeColor = System.Drawing.Color.White
        Me.virg.Location = New System.Drawing.Point(253, 78)
        Me.virg.Name = "virg"
        Me.virg.Size = New System.Drawing.Size(39, 36)
        Me.virg.TabIndex = 155
        Me.virg.Text = ","
        Me.virg.UseVisualStyleBackColor = True
        '
        'U
        '
        Me.U.BackgroundImage = CType(resources.GetObject("U.BackgroundImage"), System.Drawing.Image)
        Me.U.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.U.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.U.ForeColor = System.Drawing.Color.White
        Me.U.Location = New System.Drawing.Point(253, 12)
        Me.U.Name = "U"
        Me.U.Size = New System.Drawing.Size(39, 36)
        Me.U.TabIndex = 154
        Me.U.Text = "U"
        Me.U.UseVisualStyleBackColor = True
        '
        'Clavier
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 159)
        Me.Controls.Add(Me.N0)
        Me.Controls.Add(Me.egale)
        Me.Controls.Add(Me.plus)
        Me.Controls.Add(Me.moins)
        Me.Controls.Add(Me.etoile)
        Me.Controls.Add(Me.sur)
        Me.Controls.Add(Me.N1)
        Me.Controls.Add(Me.N2)
        Me.Controls.Add(Me.N3)
        Me.Controls.Add(Me.N8)
        Me.Controls.Add(Me.N7)
        Me.Controls.Add(Me.N5)
        Me.Controls.Add(Me.N9)
        Me.Controls.Add(Me.N4)
        Me.Controls.Add(Me.N6)
        Me.Controls.Add(Me.à)
        Me.Controls.Add(Me.ç)
        Me.Controls.Add(Me.ù)
        Me.Controls.Add(Me.è)
        Me.Controls.Add(Me.é)
        Me.Controls.Add(Me.arou)
        Me.Controls.Add(Me.A)
        Me.Controls.Add(Me.B)
        Me.Controls.Add(Me.V)
        Me.Controls.Add(Me.C)
        Me.Controls.Add(Me.X)
        Me.Controls.Add(Me.L)
        Me.Controls.Add(Me.W)
        Me.Controls.Add(Me.K)
        Me.Controls.Add(Me.J)
        Me.Controls.Add(Me.H)
        Me.Controls.Add(Me.G)
        Me.Controls.Add(Me.F)
        Me.Controls.Add(Me.D)
        Me.Controls.Add(Me.S)
        Me.Controls.Add(Me.Q)
        Me.Controls.Add(Me.P)
        Me.Controls.Add(Me.O)
        Me.Controls.Add(Me.I)
        Me.Controls.Add(Me.Y)
        Me.Controls.Add(Me.T)
        Me.Controls.Add(Me.R)
        Me.Controls.Add(Me.E)
        Me.Controls.Add(Me.Z)
        Me.Controls.Add(Me.Maj)
        Me.Controls.Add(Me.ex_in)
        Me.Controls.Add(Me.pt)
        Me.Controls.Add(Me.espace)
        Me.Controls.Add(Me.M)
        Me.Controls.Add(Me.pv)
        Me.Controls.Add(Me.pt2)
        Me.Controls.Add(Me.N)
        Me.Controls.Add(Me.virg)
        Me.Controls.Add(Me.U)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Clavier"
        Me.Opacity = 0.9R
        Me.Text = "Clavier"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents N0 As System.Windows.Forms.Button
    Friend WithEvents egale As System.Windows.Forms.Button
    Friend WithEvents plus As System.Windows.Forms.Button
    Friend WithEvents moins As System.Windows.Forms.Button
    Friend WithEvents etoile As System.Windows.Forms.Button
    Friend WithEvents sur As System.Windows.Forms.Button
    Friend WithEvents N1 As System.Windows.Forms.Button
    Friend WithEvents N2 As System.Windows.Forms.Button
    Friend WithEvents N3 As System.Windows.Forms.Button
    Friend WithEvents N8 As System.Windows.Forms.Button
    Friend WithEvents N7 As System.Windows.Forms.Button
    Friend WithEvents N5 As System.Windows.Forms.Button
    Friend WithEvents N9 As System.Windows.Forms.Button
    Friend WithEvents N4 As System.Windows.Forms.Button
    Friend WithEvents N6 As System.Windows.Forms.Button
    Friend WithEvents à As System.Windows.Forms.Button
    Friend WithEvents ç As System.Windows.Forms.Button
    Friend WithEvents ù As System.Windows.Forms.Button
    Friend WithEvents è As System.Windows.Forms.Button
    Friend WithEvents é As System.Windows.Forms.Button
    Friend WithEvents arou As System.Windows.Forms.Button
    Friend WithEvents A As System.Windows.Forms.Button
    Friend WithEvents B As System.Windows.Forms.Button
    Friend WithEvents V As System.Windows.Forms.Button
    Friend WithEvents C As System.Windows.Forms.Button
    Friend WithEvents X As System.Windows.Forms.Button
    Friend WithEvents L As System.Windows.Forms.Button
    Friend WithEvents W As System.Windows.Forms.Button
    Friend WithEvents K As System.Windows.Forms.Button
    Friend WithEvents J As System.Windows.Forms.Button
    Friend WithEvents H As System.Windows.Forms.Button
    Friend WithEvents G As System.Windows.Forms.Button
    Friend WithEvents F As System.Windows.Forms.Button
    Friend WithEvents D As System.Windows.Forms.Button
    Friend WithEvents S As System.Windows.Forms.Button
    Friend WithEvents Q As System.Windows.Forms.Button
    Friend WithEvents P As System.Windows.Forms.Button
    Friend WithEvents O As System.Windows.Forms.Button
    Friend WithEvents I As System.Windows.Forms.Button
    Friend WithEvents Y As System.Windows.Forms.Button
    Friend WithEvents T As System.Windows.Forms.Button
    Friend WithEvents R As System.Windows.Forms.Button
    Friend WithEvents E As System.Windows.Forms.Button
    Friend WithEvents Z As System.Windows.Forms.Button
    Friend WithEvents Maj As System.Windows.Forms.Button
    Friend WithEvents ex_in As System.Windows.Forms.Button
    Friend WithEvents pt As System.Windows.Forms.Button
    Friend WithEvents espace As System.Windows.Forms.Button
    Friend WithEvents M As System.Windows.Forms.Button
    Friend WithEvents pv As System.Windows.Forms.Button
    Friend WithEvents pt2 As System.Windows.Forms.Button
    Friend WithEvents N As System.Windows.Forms.Button
    Friend WithEvents virg As System.Windows.Forms.Button
    Friend WithEvents U As System.Windows.Forms.Button
End Class
