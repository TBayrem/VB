﻿Public Class Clavier



    Private Sub Maj_Click(sender As Object, e As EventArgs) Handles Maj.Click



        If maj_min = 1 Then
            majus = True

            maj_min = 0
        Else

            majus = False
            maj_min = 1

        End If
    End Sub

    Private Sub A_Click(sender As Object, e As EventArgs) Handles A.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("A")
        Else : SendKeys.Send("a")
        End If
    End Sub

    Private Sub Z_Click(sender As Object, e As EventArgs) Handles Z.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("Z")
        Else : SendKeys.Send("z")
        End If
    End Sub

    Private Sub E_Click(sender As Object, e As EventArgs) Handles E.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("E")
        Else : SendKeys.Send("e")
        End If
    End Sub

    Private Sub R_Click(sender As Object, e As EventArgs) Handles R.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("R")
        Else : SendKeys.Send("r")
        End If
    End Sub


    Private Sub T_Click(sender As Object, e As EventArgs) Handles T.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("T")
        Else : SendKeys.Send("t")
        End If
    End Sub

    Private Sub Y_Click(sender As Object, e As EventArgs) Handles Y.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("Y")
        Else : SendKeys.Send("y")
        End If
    End Sub

    Private Sub U_Click(sender As Object, e As EventArgs) Handles U.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("U")
        Else : SendKeys.Send("u")
        End If
    End Sub

    Private Sub I_Click(sender As Object, e As EventArgs) Handles I.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("I")
        Else : SendKeys.Send("i")
        End If
    End Sub

    Private Sub O_Click(sender As Object, e As EventArgs) Handles O.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("O")
        Else : SendKeys.Send("o")
        End If
    End Sub

    Private Sub P_Click(sender As Object, e As EventArgs) Handles P.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("P")
        Else : SendKeys.Send("p")
        End If
    End Sub

    Private Sub Q_Click(sender As Object, e As EventArgs) Handles Q.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("Q")
        Else : SendKeys.Send("q")
        End If
    End Sub

    Private Sub S_Click(sender As Object, e As EventArgs) Handles S.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("S")
        Else : SendKeys.Send("s")
        End If
    End Sub

    Private Sub D_Click(sender As Object, e As EventArgs) Handles D.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("D")
        Else : SendKeys.Send("d")
        End If
    End Sub

    Private Sub F_Click(sender As Object, e As EventArgs) Handles F.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("F")
        Else : SendKeys.Send("f")
        End If
    End Sub

    Private Sub G_Click(sender As Object, e As EventArgs) Handles G.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("G")
        Else : SendKeys.Send("g")
        End If
    End Sub

    Private Sub H_Click(sender As Object, e As EventArgs) Handles H.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("H")
        Else : SendKeys.Send("h")
        End If
    End Sub

    Private Sub J_Click(sender As Object, e As EventArgs) Handles J.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("J")
        Else : SendKeys.Send("j")
        End If
    End Sub

    Private Sub K_Click(sender As Object, e As EventArgs) Handles K.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("K")
        Else : SendKeys.Send("k")
        End If
    End Sub

    Private Sub L_Click(sender As Object, e As EventArgs) Handles L.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("L")
        Else : SendKeys.Send("l")
        End If
    End Sub

    Private Sub M_Click(sender As Object, e As EventArgs) Handles M.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("M")
        Else : SendKeys.Send("m")
        End If
    End Sub

    Private Sub W_Click(sender As Object, e As EventArgs) Handles W.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("W")
        Else : SendKeys.Send("w")
        End If
    End Sub

    Private Sub X_Click(sender As Object, e As EventArgs) Handles X.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("X")
        Else : SendKeys.Send("x")
        End If
    End Sub

    Private Sub C_Click(sender As Object, e As EventArgs) Handles C.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("C")
        Else : SendKeys.Send("c")
        End If
    End Sub

    Private Sub V_Click(sender As Object, e As EventArgs) Handles V.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("V")
        Else : SendKeys.Send("v")
        End If
    End Sub

    Private Sub B_Click(sender As Object, e As EventArgs) Handles B.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("B")
        Else : SendKeys.Send("b")
        End If
    End Sub

    Private Sub N_Click(sender As Object, e As EventArgs) Handles N.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("N")
        Else : SendKeys.Send("n")
        End If
    End Sub

    Private Sub N1_Click(sender As Object, e As EventArgs) Handles N1.Click
        AppActivate(Str)


        SendKeys.Send("1")


    End Sub

    Private Sub arou_Click(sender As Object, e As EventArgs) Handles arou.Click
        AppActivate(Str)


        SendKeys.Send("@")
    End Sub

    Private Sub virg_Click(sender As Object, e As EventArgs) Handles virg.Click
        AppActivate(Str)


        SendKeys.Send(",")
    End Sub

    Private Sub pv_Click(sender As Object, e As EventArgs) Handles pv.Click
        AppActivate(Str)


        SendKeys.Send(";")
    End Sub

    Private Sub pt_Click(sender As Object, e As EventArgs) Handles pt.Click
        AppActivate(Str)


        SendKeys.Send(".")
    End Sub

    Private Sub pt2_Click(sender As Object, e As EventArgs) Handles pt2.Click
        AppActivate(Str)


        SendKeys.Send(":")
    End Sub

    Private Sub ex_in_Click(sender As Object, e As EventArgs) Handles ex_in.Click
        AppActivate(Str)

        If majus = True Then
            SendKeys.Send("!")
        Else : SendKeys.Send("?")
        End If
    End Sub

    Private Sub é_Click(sender As Object, e As EventArgs) Handles é.Click
        AppActivate(Str)


        SendKeys.Send("é")
    End Sub

    Private Sub è_Click(sender As Object, e As EventArgs) Handles è.Click
        AppActivate(Str)


        SendKeys.Send("è")
    End Sub

    Private Sub espace_Click(sender As Object, e As EventArgs) Handles espace.Click
        AppActivate(Str)


        SendKeys.Send(" ")
    End Sub

    Private Sub à_Click(sender As Object, e As EventArgs) Handles à.Click
        AppActivate(Str)


        SendKeys.Send("à")
    End Sub

    Private Sub ç_Click(sender As Object, e As EventArgs) Handles ç.Click
        AppActivate(Str)


        SendKeys.Send("ç")
    End Sub

    Private Sub ù_Click(sender As Object, e As EventArgs) Handles ù.Click
        AppActivate(Str)


        SendKeys.Send("ù")
    End Sub

    Private Sub N0_Click(sender As Object, e As EventArgs) Handles N0.Click
        AppActivate(Str)


        SendKeys.Send("0")
    End Sub

    Private Sub egale_Click(sender As Object, e As EventArgs) Handles egale.Click
        AppActivate(Str)


        SendKeys.Send("=")
    End Sub

    Private Sub plus_Click(sender As Object, e As EventArgs) Handles plus.Click
        AppActivate(Str)


        SendKeys.Send("+")
    End Sub

    Private Sub N2_Click(sender As Object, e As EventArgs) Handles N2.Click
        AppActivate(Str)


        SendKeys.Send("2")
    End Sub

    Private Sub N3_Click(sender As Object, e As EventArgs) Handles N3.Click
        AppActivate(Str)


        SendKeys.Send("3")
    End Sub

    Private Sub moins_Click(sender As Object, e As EventArgs) Handles moins.Click
        AppActivate(Str)


        SendKeys.Send("-")
    End Sub

    Private Sub N4_Click(sender As Object, e As EventArgs) Handles N4.Click
        AppActivate(Str)


        SendKeys.Send("4")
    End Sub

    Private Sub N5_Click(sender As Object, e As EventArgs) Handles N5.Click
        AppActivate(Str)


        SendKeys.Send("5")
    End Sub

    Private Sub N6_Click(sender As Object, e As EventArgs) Handles N6.Click
        AppActivate(Str)


        SendKeys.Send("6")
    End Sub

    Private Sub etoile_Click(sender As Object, e As EventArgs) Handles etoile.Click
        AppActivate(Str)


        SendKeys.Send("*")
    End Sub

    Private Sub sur_Click(sender As Object, e As EventArgs) Handles sur.Click
        AppActivate(Str)


        SendKeys.Send("/")
    End Sub

    Private Sub N9_Click(sender As Object, e As EventArgs) Handles N9.Click
        AppActivate(Str)


        SendKeys.Send("9")
    End Sub

    Private Sub N8_Click(sender As Object, e As EventArgs) Handles N8.Click
        AppActivate(Str)


        SendKeys.Send("8")
    End Sub

    Private Sub N7_Click(sender As Object, e As EventArgs) Handles N7.Click
        AppActivate(Str)


        SendKeys.Send("7")
    End Sub

    Private Sub Supp_Click(sender As Object, e As EventArgs)


    End Sub

   
End Class