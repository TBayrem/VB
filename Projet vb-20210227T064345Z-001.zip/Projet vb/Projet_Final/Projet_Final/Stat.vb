﻿Public Class Stat

    Private Sub Stat_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'TODO: cette ligne de code charge les données dans la table 'DataSet2.VENTE'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.VENTETableAdapter.Fill(Me.DataSet2.VENTE)

        Me.C_A_V.RefreshReport()
        Me.E_V_M.RefreshReport()
        Me.Benefice_M.RefreshReport()
        Me.Benefice_A.RefreshReport()


        Benefice_M.Hide()
        Benefice_A.Hide()
        C_A_V.Hide()
        E_V_M.Hide()
    End Sub



    Private Sub bnt_C_A_V_Click(sender As Object, e As EventArgs) Handles bnt_C_A_V.Click
        C_A_V.Show()
        E_V_M.Hide()
        Benefice_M.Hide()
        Benefice_A.Hide()

    End Sub

    Private Sub Btn_E_V_M_Click(sender As Object, e As EventArgs) Handles Btn_E_V_M.Click
        C_A_V.Hide()
        E_V_M.Show()
        Benefice_M.Hide()
        Benefice_A.Hide()
    End Sub

    Private Sub Btn_Benfice_M_Click(sender As Object, e As EventArgs) Handles Btn_Benfice_M.Click
        Benefice_M.Show()
        C_A_V.Hide()
        E_V_M.Hide()
        Benefice_A.Hide()
    End Sub

    Private Sub Btn_Benefice_A_Click(sender As Object, e As EventArgs) Handles Btn_Benefice_A.Click
        Benefice_M.Hide()
        Benefice_A.Show()
        C_A_V.Hide()
        E_V_M.Hide()
    End Sub
End Class