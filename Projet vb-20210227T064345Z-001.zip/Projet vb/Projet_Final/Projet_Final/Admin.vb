﻿Public Class Admin

    Private Sub Admin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'DataSet_coffe.PRODUIT'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.PRODUITTableAdapter.Fill(Me.DataSet_coffe.PRODUIT)
        'TODO: cette ligne de code charge les données dans la table 'DataSet_coffe.VENDEUR'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.VENDEURTableAdapter.Fill(Me.DataSet_coffe.VENDEUR)
        Btn_Clavier.SetBounds(570, 750, 165, 20)
        Panel_Admin.SetBounds(380, 20, 672, 166)
        Panel_Admin.BackColor = Color.FromArgb(170, Color.White)
        Menu.BackColor = Color.FromArgb(170, Color.White)
        Btn_Logout.SetBounds(1300, 10, 50, 50)
        Titre.SetBounds(600, 150, 50, 50)
        Titre.AutoSize = True
        Titre.Hide()
        Menu.Hide()
        P_Notif.Hide()
        Me.BackgroundImage = Image.FromFile(img + "théme.jpg")
        Btn_Vendeur.BackgroundImage = Image.FromFile(img + "member.png")
        Btn_Vendeur.BackgroundImageLayout = ImageLayout.Stretch
        Btn_Produit.BackgroundImage = Image.FromFile(img + "Coffee.bmp")
        Btn_Produit.BackgroundImageLayout = ImageLayout.Stretch

        Btn_Vente.BackgroundImage = Image.FromFile(img + "vente.png")
        Btn_Vente.BackgroundImageLayout = ImageLayout.Stretch
        Btn_Stat.BackgroundImage = Image.FromFile(img + "Stat.png")
        Btn_Stat.BackgroundImageLayout = ImageLayout.Stretch
        Btn_Logout.BackgroundImage = Image.FromFile(img + "logout.png")
        Btn_Logout.BackgroundImageLayout = ImageLayout.Stretch


    End Sub

    Private Sub Btn_Clavier_Click(sender As Object, e As EventArgs) Handles Btn_Clavier.Click
        'importer le clavier virtuel
        Me.AddOwnedForm(Clavier)
        If iclavier = 0 Then
            Clavier.Show()
            Clavier.SetBounds(390, 585, 560, 164)
            iclavier = 1
        Else

            Clavier.Hide()
            iclavier = 0

        End If
    End Sub

    Private Sub Btn_Logout_Click(sender As Object, e As EventArgs) Handles Btn_Logout.Click
        Me.Hide()
        Titre.Hide()
        Menu.Hide()
        Connnect.Show()
        Me.Close()

        Stat.Close()
        Ventesvb.Close()
        Ajouter.Close()
        Afficher.Close()
        Supprimer.Close()
        Modifier.Close()

        P_Notif.Hide()
    End Sub

    Private Sub Btn_Vendeur_Click(sender As Object, e As EventArgs) Handles Btn_Vendeur.Click
        Supprimer.FLP_Produit.Hide()
        Menu.Show()
        Titre.Show()
        Ajouter.PA_Vendeur.Show()
        Ajouter.PA_Vendeur.SetBounds(40, 60, 500, 148)
        Ajouter.PA_Produit.Hide()
        Modifier.PA_Produit.Hide()
        Modifier.PA_Vendeur.Hide()


        Titre.Text = Btn_Vendeur.Text
        P_Notif.Hide()
        Stat.Close()
        Ventesvb.Close()
    End Sub

    Private Sub Btn_Produit_Click(sender As Object, e As EventArgs) Handles Btn_Produit.Click
        Supprimer.FLP_Vendeur.Hide()
        Stat.Close()
        Ventesvb.Close()

        Menu.Show()
        Titre.Show()
        Ajouter.PA_Vendeur.Hide()

        Ajouter.PA_Produit.Show()
        Ajouter.PA_Produit.SetBounds(40, 60, 600, 200)

        Modifier.PA_Vendeur.Hide()
        Modifier.PA_Produit.Hide()

        Titre.Text = Btn_Produit.Text
        P_Notif.Hide()
    End Sub

    Private Sub Btn_Vente_Click(sender As Object, e As EventArgs) Handles Btn_Vente.Click
        Menu.Hide()
        Titre.Show()
        Titre.Text = Btn_Vente.Text
        Afficher.Close()
        Supprimer.Close()
        Ajouter.Close()
        Modifier.Close()
        Ventesvb.Show()
        Ventesvb.SetBounds(200, 200, 1000, 380)
        Str = "Ventesvb"
        P_Notif.Hide()
    End Sub

    Private Sub Btn_Stat_Click(sender As Object, e As EventArgs) Handles Btn_Stat.Click
        Menu.Hide()
        Titre.Show()
        Afficher.Close()
        Supprimer.Close()
        Ajouter.Close()
        Modifier.Close()
        Ventesvb.Close()
        Stat.Show()
        Stat.SetBounds(380, 200, 672, 380)
        Titre.Text = Btn_Stat.Text
        P_Notif.Hide()
    End Sub

    Private Sub Btn_Affich_Click(sender As Object, e As EventArgs) Handles Btn_Affich.Click
        Me.AddOwnedForm(Afficher)
        P_Notif.Hide()

        Str = "Afficher"


        Afficher.Show()
        Supprimer.Hide()
        Ajouter.Hide()
        Modifier.Hide()
       

       

        Afficher.SetBounds(380, 200, 672, 350)
        Afficher.AutoSize = True
        If Titre.Text = Btn_Vendeur.Text Then
            Afficher.VENDEURTableAdapter.Fill(Me.DataSet_coffe.VENDEUR)
            Afficher.Vendeur_GV.DataSource = VENDEURBindingSource


            Afficher.Vendeur_GV.SetBounds(5, 5, 515, 307)
            Afficher.Produit_GV.Hide()
            Afficher.Vendeur_GV.Show()
        Else
            Afficher.PRODUITTableAdapter.Fill(Me.DataSet_coffe.PRODUIT)
            Afficher.Produit_GV.DataSource = PRODUITBindingSource

            Afficher.Produit_GV.SetBounds(5, 5, 515, 307)
            Afficher.Produit_GV.Show()
            Afficher.Vendeur_GV.Hide()
        End If


    End Sub

    Private Sub Btn_Supp_Click(sender As Object, e As EventArgs) Handles Btn_Supp.Click
        Me.AddOwnedForm(Supprimer)
        Str = "Supprimer"
        Supprimer.Show()
        Afficher.Hide()
        Ajouter.Hide()
        Modifier.Hide()

        Supprimer.SetBounds(380, 200, 672, 350)
        P_Notif.Hide()
    End Sub

    Private Sub Btn_Ajout_Click(sender As Object, e As EventArgs) Handles Btn_Ajout.Click
        Me.AddOwnedForm(Ajouter)
        Str = "Ajouter"
        Ajouter.Show()

        Supprimer.Hide()
        Afficher.Hide()
        Modifier.Hide()
        If Titre.Text = Btn_Vendeur.Text Then
            Ajouter.PA_Vendeur.Show()
            Ajouter.PA_Produit.Hide()
        Else
            Ajouter.PA_Vendeur.Hide()
            Ajouter.PA_Produit.Show()

        End If
        Ajouter.SetBounds(380, 200, 672, 350)
        P_Notif.Hide()
    End Sub

    Private Sub Btn_Modif_Click(sender As Object, e As EventArgs) Handles Btn_Modif.Click
        Me.AddOwnedForm(Modifier)
        Str = "Modifier"
        Modifier.Show()

        Supprimer.Hide()
        Afficher.Hide()
        Ajouter.Hide()
        Ajouter.PA_Vendeur.Hide()
        Ajouter.PA_Produit.Hide()

        Modifier.SetBounds(380, 200, 672, 350)
        P_Notif.Hide()
    End Sub
End Class