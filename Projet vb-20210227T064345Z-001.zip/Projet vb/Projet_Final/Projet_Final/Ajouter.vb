﻿Public Class Ajouter


    Private Sub Ajouter_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(Admin.P_Notif)
        Admin.P_Notif.SetBounds(500, 10, 200, 79)
        PA_Vendeur.Hide()
        PA_Produit.Hide()
        If Admin.Titre.Text = Admin.Btn_Vendeur.Text Then
            PA_Vendeur.Show()
            PA_Vendeur.SetBounds(40, 60, 500, 148)

        Else
            PA_Produit.Show()
            PA_Produit.SetBounds(40, 60, 600, 200)
        End If
    End Sub

    Private Sub Btn_Ajout_Click(sender As Object, e As EventArgs) Handles Btn_Ajout.Click
        Admin.P_Notif.Show()
        If Admin.Titre.Text = Admin.Btn_Vendeur.Text Then


            Try
                Vendeur.InsertQuery(txt_Id_V.Text, txt_Nom.Text, txt_Log.Text, txt_Pass.Text, CStr(CB_CP.SelectedItem))
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Ajout reussite"
                Admin.L_Notif.Text = "Confirmation"

                txt_Id_V.Text = ""
                txt_Nom.Text = ""
                txt_Log.Text = ""
                txt_Pass.Text = ""
                CB_CP.SelectedIndex = -1
            Catch ex As Exception
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "NO.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Ajout échoué "
                Admin.L_Notif.Text = "Eurreur"


            End Try



        Else

            Try
                Produit.InsertQuery(CStr(CB_CPA.SelectedItem)(0) + txt_Id_P.Text, txt_lib.Text, CDec(txt_PV.Text), CDec(Txt_PA.Text), CDec(txt_Qte.Text))

                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Ajout reussite"
                Admin.L_Notif.Text = "Confirmation"


            Catch ex As Exception
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "NO.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Ajout échouée"
                Admin.L_Notif.Text = "Erreur"


            End Try


        End If
    End Sub

    Private Sub Btn_Annul_Click(sender As Object, e As EventArgs) Handles Btn_Annul.Click
        Admin.P_Notif.Hide()



        txt_Id_V.Text = ""
        txt_Nom.Text = ""
        txt_Log.Text = ""
        txt_Pass.Text = ""
        CB_CP.SelectedIndex = -1
        txt_Id_P.Text = ""
        txt_lib.Text = ""
        txt_PV.Text = ""
        Txt_PA.Text = ""
        txt_Qte.Text = ""




    End Sub
End Class