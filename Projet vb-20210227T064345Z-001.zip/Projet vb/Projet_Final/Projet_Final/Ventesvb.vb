﻿Public Class Ventesvb

    Private Sub Ventesvb_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.AllowTransparency = True

        'TODO: cette ligne de code charge les données dans la table 'DataSet2.VENTE'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.VENTETableAdapter.Fill(Me.DataSet2.VENTE)
        Date_Fac.Text = "le: " + CStr(Today)
        Num_Fac.Text = "N°:" + CStr(vente.GetData.Rows.Count)
        Btn_Valider.Enabled = False
        btn_Supp_elem.BackgroundImage = Image.FromFile(img + "No.png")
        btn_Supp_elem.BackgroundImageLayout = ImageLayout.Stretch

    End Sub

   
    Private Sub Btn_Hot_Click(sender As Object, e As EventArgs) Handles Btn_Hot.Click
        FLP_Produit_V.Controls.Clear()
        Dim j As Integer = 0
        For j = 0 To m - 1

            If Produit.GetData.Rows.Item(j).ItemArray(0)(0) = Btn_Hot.Text(0) Then
                Dim x As New Modele_Produit()
                Dim Gb As New GroupBox
                Try


                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + CStr(Produit.GetData.Rows.Item(j).ItemArray(0)) + ".jpg"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                Catch ex As Exception
                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + "X.bmp"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                End Try
                FLP_Produit_V.Controls.Add(Gb)

            End If

        Next
    End Sub

    Private Sub Btn_Ice_Click(sender As Object, e As EventArgs) Handles Btn_Ice.Click
        FLP_Produit_V.Controls.Clear()
        Dim j As Integer = 0
        For j = 0 To m - 1

            If Produit.GetData.Rows.Item(j).ItemArray(0)(0) = Btn_Ice.Text(0) Then
                Dim x As New Modele_Produit()
                Dim Gb As New GroupBox
                Try


                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + CStr(Produit.GetData.Rows.Item(j).ItemArray(0)) + ".jpg"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                Catch ex As Exception
                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + "X.bmp"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                End Try
                FLP_Produit_V.Controls.Add(Gb)

            End If

        Next
    End Sub

    Private Sub Btn_Smoothies_Click(sender As Object, e As EventArgs) Handles Btn_Smoothies.Click
        FLP_Produit_V.Controls.Clear()
        Dim j As Integer = 0
        For j = 0 To m - 1

            If Produit.GetData.Rows.Item(j).ItemArray(0)(0) = Btn_Smoothies.Text(0) Then
                Dim x As New Modele_Produit()
                Dim Gb As New GroupBox
                Try

              
                Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + CStr(Produit.GetData.Rows.Item(j).ItemArray(0)) + ".jpg"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                Catch ex As Exception
                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + "X.bmp"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                End Try
                FLP_Produit_V.Controls.Add(Gb)

            End If

        Next
    End Sub

    Private Sub Btn_Pastries_Click(sender As Object, e As EventArgs) Handles Btn_Pastries.Click
        FLP_Produit_V.Controls.Clear()


        Dim j As Integer = 0
        For j = 0 To m - 1

            If Produit.GetData.Rows.Item(j).ItemArray(0)(0) = Btn_Pastries.Text(0) Then
                Dim x As New Modele_Produit()
                Dim Gb As New GroupBox
                Try


                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + CStr(Produit.GetData.Rows.Item(j).ItemArray(0)) + ".jpg"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                Catch ex As Exception
                    Gb = x.model(Produit.GetData.Rows.Item(j).ItemArray(1), Image.FromFile(img + "X.bmp"), Produit.GetData.Rows.Item(j).ItemArray(2), CDec(Produit.GetData.Rows.Item(j).ItemArray(3)), CDec(Produit.GetData.Rows.Item(j).ItemArray(4)))
                End Try
                FLP_Produit_V.Controls.Add(Gb)

            End If

        Next
    End Sub

    Private Sub Bt_Annul_Click(sender As Object, e As EventArgs) Handles Bt_Annul.Click
        DGV_COMM.Rows.Clear()

        Btn_Valider.Enabled = False


    End Sub

    Private Sub Btn_Valider_Click(sender As Object, e As EventArgs) Handles Btn_Valider.Click

        Facture.DeleteAll()

        Dim k As Integer = DGV_COMM.Rows.Count - 1
        Dim i As Integer
        For i = 0 To k - 1

            Facture.InsertQuery(CStr(DGV_COMM.Item(2, i).Value), vente.GetData.Rows.Count, Today, CDec(DGV_COMM.Item(1, i).Value), CDec(DGV_COMM.Item(4, i).Value), CDec(DGV_COMM.Item(6, i).Value), CDec(Totaux1.Text.Remove(0, 17)))
            Produit.UpdateQte(CInt(DGV_COMM.Item(0, i).Value) - CInt(DGV_COMM.Item(1, i).Value), CStr(DGV_COMM.Item(2, i).Value))
        Next
        vente.InsertQuery(vente.GetData.Rows.Count + 1, Today, CDec(Totaux1.Text.Remove(0, 17)), CDec(Totaux2.Text.Remove(0, 18)), id_vc)

        Factur.Show()
        DGV_COMM.Rows.Clear()


    End Sub

    
    
    Private Sub btn_Supp_elem_Click(sender As Object, e As EventArgs) Handles btn_Supp_elem.Click
        DGV_COMM.Rows.Remove(DGV_COMM.CurrentRow)
        Dim n As Integer = DGV_COMM.Rows.Count
        Dim y As Double = 0
        Dim x As Double = 0
        For j = 0 To n - 1
            y = y + CDbl(DGV_COMM.Item(6, j).Value)
            x = x + CDbl(DGV_COMM.Item(5, j).Value)
        Next



        Totaux1.Text = "Totaux de vente :" + CStr(y)
        Totaux2.Text = "Totaux d'achat   :" + CStr(x)
        Btn_Valider.Enabled = True
     
    End Sub
End Class