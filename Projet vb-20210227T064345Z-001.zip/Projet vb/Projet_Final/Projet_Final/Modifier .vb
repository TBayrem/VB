﻿Public Class Modifier

    Private Sub Btn_search_Click(sender As Object, e As EventArgs) Handles Btn_search.Click
        Dim i As Integer = 0

        Dim trouve As Boolean = False
        If Admin.Titre.Text = Admin.Btn_Vendeur.Text Then

            While i <= n - 1 And trouve = False
                If CStr(Vendeur.GetData.Rows.Item(i).ItemArray(0)) = txt_rech.Text Then
                    trouve = True
                Else
                    i = i + 1
                End If
            End While

            If trouve = True Then
                PA_Produit.Hide()
                PA_Vendeur.Show()
                PA_Vendeur.SetBounds(40, 60, 500, 148)
                txt_Nom.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(1))
                txt_Log.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(2))
                txt_Pass.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(3))
                CB_CP.Text = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(4))
                If txt_rech.Text = "1" Then

                    Admin.P_Notif.Show()
                    Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                    Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                    Admin.L_MSG.Text = "ID  ADmin"
                    Admin.L_Notif.Text = "Eurreur"
                    Btn_Modif.Enabled = False
                    Btn_Annul.Enabled = False
                Else
                    Admin.P_Notif.Show()
                    Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                    Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                    Admin.L_MSG.Text = "ID  trouvée"
                    Admin.L_Notif.Text = "Confirmation"
                    Btn_Modif.Enabled = True
                    Btn_Annul.Enabled = True
                End If

            Else
                PA_Vendeur.Hide()
                PA_Produit.Hide()
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "ID non trouvée"
                Admin.L_Notif.Text = "Eurreur"
                Btn_Modif.Enabled = False
                Btn_Annul.Enabled = False
            End If

        Else

            While i <= m - 1 And trouve = False
                If CStr(Produit.GetData.Rows.Item(i).ItemArray(0)) = txt_rech.Text Then
                    trouve = True
                Else
                    i = i + 1
                End If
            End While
            If trouve = True Then
                PA_Vendeur.Hide()
                PA_Produit.Show()
                PA_Produit.SetBounds(40, 60, 600, 200)

                txt_lib.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(1))
                txt_PV.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(2))
                Txt_PA.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(3))
                txt_Qte.Text = CStr(Produit.GetData.Rows.Item(i).ItemArray(4))


                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "ID  trouvée"
                Admin.L_Notif.Text = "Confirmation"
                Btn_Modif.Enabled = True
                Btn_Annul.Enabled = True
            Else
                PA_Vendeur.Hide()
                PA_Produit.Hide()
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "ID non trouvée"
                Admin.L_Notif.Text = "Eurreur"
                Btn_Modif.Enabled = False
                Btn_Annul.Enabled = False
            End If
        End If

    End Sub

    Private Sub Btn_Modif_Click(sender As Object, e As EventArgs) Handles Btn_Modif.Click
        Admin.P_Notif.Show()
        If Admin.Titre.Text = Admin.Btn_Vendeur.Text Then
            Try
                Vendeur.UpdateQuery(txt_rech.Text, txt_Nom.Text, txt_Log.Text, txt_Pass.Text, CStr(CB_CP.SelectedItem), txt_rech.Text)
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Modification réussite"
                Admin.L_Notif.Text = "confirmation"


            Catch ex As Exception
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Modification échoué"
                Admin.L_Notif.Text = "Eurreur"

            End Try

        Else
            Try
                Produit.UpdateQuery(txt_rech.Text, txt_lib.Text, CDec(txt_PV.Text), CDec(Txt_PA.Text), CDec(txt_Qte.Text), txt_rech.Text)
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "Yes.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Modification réussite"
                Admin.L_Notif.Text = "confirmation"

            Catch ex As Exception
                Admin.P_Notif.Show()
                Admin.P_img_N.BackgroundImage = Image.FromFile(img + "No.png")
                Admin.P_img_N.BackgroundImageLayout = ImageLayout.Stretch
                Admin.L_MSG.Text = "Modification échoué"
                Admin.L_Notif.Text = "Eurreur"


            End Try
        End If
    End Sub

    Private Sub Modifier_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Controls.Add(Admin.P_Notif)
        Admin.P_Notif.SetBounds(500, 10, 200, 79)
        PA_Produit.Hide()
        PA_Vendeur.Hide()
        Btn_Modif.Enabled = False
        Btn_Annul.Enabled = False


    End Sub

    Private Sub Btn_Annul_Click(sender As Object, e As EventArgs) Handles Btn_Annul.Click
        Admin.P_Notif.Hide()
        PA_Produit.Hide()
        PA_Vendeur.Hide()
        txt_rech.Text = ""

    End Sub
End Class