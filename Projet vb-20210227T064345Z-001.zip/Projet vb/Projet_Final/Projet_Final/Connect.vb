﻿Public Class Connnect

    Private Sub Connnect_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'l'ajout des hundler aux textbox 
        AddHandler Txt_User.Click, AddressOf vide_user
        AddHandler Txt_Pass.Click, AddressOf vide_pass

        'positionner les controles
        Panel_login.SetBounds(100, 100, 232, 306)
        Btn_Clavier.SetBounds(570, 750, 165, 20)
        Panel_login.BackColor = Color.FromArgb(170, Color.White)



    End Sub

    'hundler event pour vider le Txt_User
    Private Sub vide_user(sender As Object, e As EventArgs)
        If Txt_User.Text = "Username" Then
            Txt_User.Text = ""
            Txt_User.ForeColor = Color.Black
        End If


    End Sub


    'hundler event pour vider le Txt_pass
    Private Sub vide_pass(sender As Object, e As EventArgs)

        If Txt_Pass.Text = "Password" Then
            Txt_Pass.Text = ""
            Txt_Pass.PasswordChar = "*"
            Txt_Pass.ForeColor = Color.Black
        End If


    End Sub
 
    Private Sub btn_Login_Click(sender As Object, e As EventArgs) Handles btn_Login.Click
      
        'recherche si username existe ou non
        Dim i As Integer = 0
        Dim trouve As Boolean = False
        While i <= n - 1 And trouve = False
            If CStr(Vendeur.GetData.Rows.Item(i).ItemArray(2)) = Txt_User.Text Then
                trouve = True
            Else
                i = i + 1
            End If
        End While

        If trouve = False Then
            'affichage si username n'existe pas
            P_Eureur_L.BackgroundImage = Image.FromFile(img + "No.png")
            P_Eureur_L.BackgroundImageLayout = ImageLayout.Stretch
            Txt_User.Text = "Username"
            Txt_User.ForeColor = Color.DarkGray
            Txt_Pass.Text = "Password"
            Txt_Pass.PasswordChar = ""
            Txt_Pass.ForeColor = Color.DarkGray
        Else
            'affichage si username existe
            P_Eureur_L.BackgroundImage = Image.FromFile(img + "Yes.png")
            P_Eureur_L.BackgroundImageLayout = ImageLayout.Stretch
            'verifier le password 
            If CStr(Vendeur.GetData.Rows.Item(i).ItemArray(3)) = Txt_Pass.Text Then
                'ouvrir les sessions admin ou compte d'un autre vendeur 
                If Txt_User.Text = "alcuardo" Then
                    Admin.Show()
                    Me.Hide()
                    Str = "Admin" 'appactivate for Clavier
                    id_vc = "1"

                    ' intialiser  l'afichage 
                    P_Eureur_L.BackgroundImageLayout = ImageLayout.Center
                    P_Eureur_P.BackgroundImageLayout = ImageLayout.Center
                    Txt_Pass.Text = "Password"
                    Txt_Pass.PasswordChar = ""
                    Txt_Pass.ForeColor = Color.DarkGray

                Else
                    id_vc = CStr(Vendeur.GetData.Rows.Item(i).ItemArray(0))
                    Compte.Show()

                    Me.Hide()
                    Str = "Compte" 'appactivate for Clavier


                    ' intialiser  l'afichage 
                    P_Eureur_L.BackgroundImageLayout = ImageLayout.Center
                    P_Eureur_P.BackgroundImageLayout = ImageLayout.Center
                    Txt_Pass.Text = "Password"
                    Txt_Pass.PasswordChar = ""
                    Txt_Pass.ForeColor = Color.DarkGray

                End If
            Else
                'affichage si le password n'existe pas 
                Txt_Pass.Text = "Password"
                Txt_Pass.PasswordChar = ""
                Txt_Pass.ForeColor = Color.DarkGray
                P_Eureur_P.BackgroundImage = Image.FromFile(img + "No.png")
                P_Eureur_P.BackgroundImageLayout = ImageLayout.Stretch
            End If
        End If



        Clavier.Hide()


            
            
    End Sub

    Private Sub Btn_Clavier_Click(sender As Object, e As EventArgs) Handles Btn_Clavier.Click
        'importer le clavier virtuel
        Me.AddOwnedForm(Clavier)
        If iclavier = 0 Then
            Clavier.Show()
            Clavier.SetBounds(390, 585, 560, 164)
            iclavier = 1
        Else

            Clavier.Hide()
            iclavier = 0

        End If

        
    End Sub


  
End Class
