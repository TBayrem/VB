﻿Public Class Factur

    Private Sub Factur_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: cette ligne de code charge les données dans la table 'DataSet3.FACTURE'. Vous pouvez la déplacer ou la supprimer selon vos besoins.
        Me.FACTURETableAdapter.Fill(Me.DataSet3.FACTURE)
        'TODO: cette ligne de code charge les données dans la table 'DataSet2.VENTE'. Vous pouvez la déplacer ou la supprimer selon vos besoins.


        Me.ReportViewer1.RefreshReport()
    End Sub
End Class