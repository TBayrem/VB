﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Supprimer
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Supprimer))
        Me.txt_supp = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.FLP_Vendeur = New System.Windows.Forms.FlowLayoutPanel()
        Me.Lab_Name = New System.Windows.Forms.Label()
        Me.Lab_Log = New System.Windows.Forms.Label()
        Me.Lab_Pass = New System.Windows.Forms.Label()
        Me.Lab_CP = New System.Windows.Forms.Label()
        Me.FLP_Produit = New System.Windows.Forms.FlowLayoutPanel()
        Me.Lab_Lib = New System.Windows.Forms.Label()
        Me.Lab_PV = New System.Windows.Forms.Label()
        Me.Lab_PA = New System.Windows.Forms.Label()
        Me.Lab_Qte = New System.Windows.Forms.Label()
        Me.Btn_search = New System.Windows.Forms.Button()
        Me.Btn_Supp = New System.Windows.Forms.Button()
        Me.Btn_Annul = New System.Windows.Forms.Button()
        Me.lab_nom = New System.Windows.Forms.Label()
        Me.Lab_login = New System.Windows.Forms.Label()
        Me.Lab_password = New System.Windows.Forms.Label()
        Me.Lab_cate = New System.Windows.Forms.Label()
        Me.Lab_libel = New System.Windows.Forms.Label()
        Me.Lab_prix_vente = New System.Windows.Forms.Label()
        Me.Lab_prix_achat = New System.Windows.Forms.Label()
        Me.Lab_qte_desp = New System.Windows.Forms.Label()
        Me.FLP_Vendeur.SuspendLayout()
        Me.FLP_Produit.SuspendLayout()
        Me.SuspendLayout()
        '
        'txt_supp
        '
        Me.txt_supp.Location = New System.Drawing.Point(151, 30)
        Me.txt_supp.Name = "txt_supp"
        Me.txt_supp.Size = New System.Drawing.Size(116, 20)
        Me.txt_supp.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(21, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(124, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Identification :"
        '
        'FLP_Vendeur
        '
        Me.FLP_Vendeur.Controls.Add(Me.Lab_Name)
        Me.FLP_Vendeur.Controls.Add(Me.Lab_Log)
        Me.FLP_Vendeur.Controls.Add(Me.Lab_Pass)
        Me.FLP_Vendeur.Controls.Add(Me.Lab_CP)
        Me.FLP_Vendeur.Controls.Add(Me.lab_nom)
        Me.FLP_Vendeur.Controls.Add(Me.Lab_login)
        Me.FLP_Vendeur.Controls.Add(Me.Lab_password)
        Me.FLP_Vendeur.Controls.Add(Me.Lab_cate)
        Me.FLP_Vendeur.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FLP_Vendeur.Location = New System.Drawing.Point(35, 80)
        Me.FLP_Vendeur.Name = "FLP_Vendeur"
        Me.FLP_Vendeur.Padding = New System.Windows.Forms.Padding(3)
        Me.FLP_Vendeur.Size = New System.Drawing.Size(433, 148)
        Me.FLP_Vendeur.TabIndex = 2
        '
        'Lab_Name
        '
        Me.Lab_Name.AutoSize = True
        Me.Lab_Name.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_Name.Location = New System.Drawing.Point(6, 3)
        Me.Lab_Name.Name = "Lab_Name"
        Me.Lab_Name.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_Name.Size = New System.Drawing.Size(139, 32)
        Me.Lab_Name.TabIndex = 0
        Me.Lab_Name.Text = "Nom et Prenom :"
        '
        'Lab_Log
        '
        Me.Lab_Log.AutoSize = True
        Me.Lab_Log.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_Log.Location = New System.Drawing.Point(6, 35)
        Me.Lab_Log.Name = "Lab_Log"
        Me.Lab_Log.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_Log.Size = New System.Drawing.Size(72, 32)
        Me.Lab_Log.TabIndex = 1
        Me.Lab_Log.Text = "Login : "
        '
        'Lab_Pass
        '
        Me.Lab_Pass.AutoSize = True
        Me.Lab_Pass.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_Pass.Location = New System.Drawing.Point(6, 67)
        Me.Lab_Pass.Name = "Lab_Pass"
        Me.Lab_Pass.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_Pass.Size = New System.Drawing.Size(98, 32)
        Me.Lab_Pass.TabIndex = 2
        Me.Lab_Pass.Text = "Password :"
        '
        'Lab_CP
        '
        Me.Lab_CP.AutoSize = True
        Me.Lab_CP.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_CP.Location = New System.Drawing.Point(6, 99)
        Me.Lab_CP.Name = "Lab_CP"
        Me.Lab_CP.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_CP.Size = New System.Drawing.Size(178, 32)
        Me.Lab_CP.TabIndex = 3
        Me.Lab_CP.Text = "Catégorie du Produit : "
        '
        'FLP_Produit
        '
        Me.FLP_Produit.Controls.Add(Me.Lab_Lib)
        Me.FLP_Produit.Controls.Add(Me.Lab_PV)
        Me.FLP_Produit.Controls.Add(Me.Lab_PA)
        Me.FLP_Produit.Controls.Add(Me.Lab_Qte)
        Me.FLP_Produit.Controls.Add(Me.Lab_libel)
        Me.FLP_Produit.Controls.Add(Me.Lab_prix_vente)
        Me.FLP_Produit.Controls.Add(Me.Lab_prix_achat)
        Me.FLP_Produit.Controls.Add(Me.Lab_qte_desp)
        Me.FLP_Produit.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.FLP_Produit.Location = New System.Drawing.Point(241, 56)
        Me.FLP_Produit.Name = "FLP_Produit"
        Me.FLP_Produit.Padding = New System.Windows.Forms.Padding(3)
        Me.FLP_Produit.Size = New System.Drawing.Size(433, 144)
        Me.FLP_Produit.TabIndex = 5
        '
        'Lab_Lib
        '
        Me.Lab_Lib.AutoSize = True
        Me.Lab_Lib.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_Lib.Location = New System.Drawing.Point(6, 3)
        Me.Lab_Lib.Name = "Lab_Lib"
        Me.Lab_Lib.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_Lib.Size = New System.Drawing.Size(78, 32)
        Me.Lab_Lib.TabIndex = 0
        Me.Lab_Lib.Text = "Libellé : "
        '
        'Lab_PV
        '
        Me.Lab_PV.AutoSize = True
        Me.Lab_PV.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_PV.Location = New System.Drawing.Point(6, 35)
        Me.Lab_PV.Name = "Lab_PV"
        Me.Lab_PV.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_PV.Size = New System.Drawing.Size(123, 32)
        Me.Lab_PV.TabIndex = 1
        Me.Lab_PV.Text = "Prix de vente : "
        '
        'Lab_PA
        '
        Me.Lab_PA.AutoSize = True
        Me.Lab_PA.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_PA.Location = New System.Drawing.Point(6, 67)
        Me.Lab_PA.Name = "Lab_PA"
        Me.Lab_PA.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_PA.Size = New System.Drawing.Size(114, 32)
        Me.Lab_PA.TabIndex = 2
        Me.Lab_PA.Text = "Prix d'achat : "
        '
        'Lab_Qte
        '
        Me.Lab_Qte.AutoSize = True
        Me.Lab_Qte.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_Qte.Location = New System.Drawing.Point(6, 99)
        Me.Lab_Qte.Name = "Lab_Qte"
        Me.Lab_Qte.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_Qte.Size = New System.Drawing.Size(94, 32)
        Me.Lab_Qte.TabIndex = 3
        Me.Lab_Qte.Text = "Quantité : "
        '
        'Btn_search
        '
        Me.Btn_search.BackgroundImage = CType(resources.GetObject("Btn_search.BackgroundImage"), System.Drawing.Image)
        Me.Btn_search.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_search.Location = New System.Drawing.Point(257, 30)
        Me.Btn_search.Name = "Btn_search"
        Me.Btn_search.Size = New System.Drawing.Size(20, 20)
        Me.Btn_search.TabIndex = 6
        Me.Btn_search.UseVisualStyleBackColor = True
        '
        'Btn_Supp
        '
        Me.Btn_Supp.Enabled = False
        Me.Btn_Supp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Supp.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Supp.Location = New System.Drawing.Point(206, 253)
        Me.Btn_Supp.Name = "Btn_Supp"
        Me.Btn_Supp.Size = New System.Drawing.Size(96, 39)
        Me.Btn_Supp.TabIndex = 7
        Me.Btn_Supp.Text = "Supprimer"
        Me.Btn_Supp.UseVisualStyleBackColor = True
        '
        'Btn_Annul
        '
        Me.Btn_Annul.Enabled = False
        Me.Btn_Annul.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Annul.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Annul.Location = New System.Drawing.Point(309, 253)
        Me.Btn_Annul.Name = "Btn_Annul"
        Me.Btn_Annul.Size = New System.Drawing.Size(96, 39)
        Me.Btn_Annul.TabIndex = 8
        Me.Btn_Annul.Text = "Annuler"
        Me.Btn_Annul.UseVisualStyleBackColor = True
        '
        'lab_nom
        '
        Me.lab_nom.AutoSize = True
        Me.lab_nom.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lab_nom.Location = New System.Drawing.Point(190, 3)
        Me.lab_nom.Name = "lab_nom"
        Me.lab_nom.Padding = New System.Windows.Forms.Padding(6)
        Me.lab_nom.Size = New System.Drawing.Size(12, 32)
        Me.lab_nom.TabIndex = 4
        '
        'Lab_login
        '
        Me.Lab_login.AutoSize = True
        Me.Lab_login.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_login.Location = New System.Drawing.Point(190, 35)
        Me.Lab_login.Name = "Lab_login"
        Me.Lab_login.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_login.Size = New System.Drawing.Size(12, 32)
        Me.Lab_login.TabIndex = 5
        '
        'Lab_password
        '
        Me.Lab_password.AutoSize = True
        Me.Lab_password.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_password.Location = New System.Drawing.Point(190, 67)
        Me.Lab_password.Name = "Lab_password"
        Me.Lab_password.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_password.Size = New System.Drawing.Size(12, 32)
        Me.Lab_password.TabIndex = 6
        '
        'Lab_cate
        '
        Me.Lab_cate.AutoSize = True
        Me.Lab_cate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_cate.Location = New System.Drawing.Point(190, 99)
        Me.Lab_cate.Name = "Lab_cate"
        Me.Lab_cate.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_cate.Size = New System.Drawing.Size(12, 32)
        Me.Lab_cate.TabIndex = 7
        '
        'Lab_libel
        '
        Me.Lab_libel.AutoSize = True
        Me.Lab_libel.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_libel.Location = New System.Drawing.Point(135, 3)
        Me.Lab_libel.Name = "Lab_libel"
        Me.Lab_libel.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_libel.Size = New System.Drawing.Size(12, 32)
        Me.Lab_libel.TabIndex = 4
        '
        'Lab_prix_vente
        '
        Me.Lab_prix_vente.AutoSize = True
        Me.Lab_prix_vente.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_prix_vente.Location = New System.Drawing.Point(135, 35)
        Me.Lab_prix_vente.Name = "Lab_prix_vente"
        Me.Lab_prix_vente.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_prix_vente.Size = New System.Drawing.Size(12, 32)
        Me.Lab_prix_vente.TabIndex = 5
        '
        'Lab_prix_achat
        '
        Me.Lab_prix_achat.AutoSize = True
        Me.Lab_prix_achat.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_prix_achat.Location = New System.Drawing.Point(135, 67)
        Me.Lab_prix_achat.Name = "Lab_prix_achat"
        Me.Lab_prix_achat.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_prix_achat.Size = New System.Drawing.Size(12, 32)
        Me.Lab_prix_achat.TabIndex = 6
        '
        'Lab_qte_desp
        '
        Me.Lab_qte_desp.AutoSize = True
        Me.Lab_qte_desp.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Lab_qte_desp.Location = New System.Drawing.Point(135, 99)
        Me.Lab_qte_desp.Name = "Lab_qte_desp"
        Me.Lab_qte_desp.Padding = New System.Windows.Forms.Padding(6)
        Me.Lab_qte_desp.Size = New System.Drawing.Size(12, 32)
        Me.Lab_qte_desp.TabIndex = 7
        '
        'Supprimer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(683, 334)
        Me.Controls.Add(Me.Btn_Annul)
        Me.Controls.Add(Me.Btn_Supp)
        Me.Controls.Add(Me.Btn_search)
        Me.Controls.Add(Me.FLP_Vendeur)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txt_supp)
        Me.Controls.Add(Me.FLP_Produit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Supprimer"
        Me.Opacity = 0.9R
        Me.Text = "Supprimer"
        Me.FLP_Vendeur.ResumeLayout(False)
        Me.FLP_Vendeur.PerformLayout()
        Me.FLP_Produit.ResumeLayout(False)
        Me.FLP_Produit.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txt_supp As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents FLP_Vendeur As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Lab_Name As System.Windows.Forms.Label
    Friend WithEvents Lab_Log As System.Windows.Forms.Label
    Friend WithEvents Lab_Pass As System.Windows.Forms.Label
    Friend WithEvents Lab_CP As System.Windows.Forms.Label
    Friend WithEvents FLP_Produit As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Lab_Lib As System.Windows.Forms.Label
    Friend WithEvents Lab_PV As System.Windows.Forms.Label
    Friend WithEvents Lab_PA As System.Windows.Forms.Label
    Friend WithEvents Lab_Qte As System.Windows.Forms.Label
    Friend WithEvents Btn_search As System.Windows.Forms.Button
    Friend WithEvents Btn_Supp As System.Windows.Forms.Button
    Friend WithEvents Btn_Annul As System.Windows.Forms.Button
    Friend WithEvents lab_nom As System.Windows.Forms.Label
    Friend WithEvents Lab_login As System.Windows.Forms.Label
    Friend WithEvents Lab_password As System.Windows.Forms.Label
    Friend WithEvents Lab_cate As System.Windows.Forms.Label
    Friend WithEvents Lab_libel As System.Windows.Forms.Label
    Friend WithEvents Lab_prix_vente As System.Windows.Forms.Label
    Friend WithEvents Lab_prix_achat As System.Windows.Forms.Label
    Friend WithEvents Lab_qte_desp As System.Windows.Forms.Label
End Class
