﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Admin
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Panel_Admin = New System.Windows.Forms.FlowLayoutPanel()
        Me.Btn_Vendeur = New System.Windows.Forms.Button()
        Me.Btn_Produit = New System.Windows.Forms.Button()
        Me.Btn_Vente = New System.Windows.Forms.Button()
        Me.Btn_Stat = New System.Windows.Forms.Button()
        Me.Btn_Logout = New System.Windows.Forms.Button()
        Me.Btn_Clavier = New System.Windows.Forms.Button()
        Me.Menu = New System.Windows.Forms.FlowLayoutPanel()
        Me.Btn_Affich = New System.Windows.Forms.Button()
        Me.Btn_Ajout = New System.Windows.Forms.Button()
        Me.Btn_Modif = New System.Windows.Forms.Button()
        Me.Btn_Supp = New System.Windows.Forms.Button()
        Me.Titre = New System.Windows.Forms.Label()
        Me.DataSet_coffe = New Projet_Final.DataSet_coffe()
        Me.VENDEURBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VENDEURTableAdapter = New Projet_Final.DataSet_coffeTableAdapters.VENDEURTableAdapter()
        Me.PRODUITBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.PRODUITTableAdapter = New Projet_Final.DataSet_coffeTableAdapters.PRODUITTableAdapter()
        Me.P_Notif = New System.Windows.Forms.Panel()
        Me.L_MSG = New System.Windows.Forms.Label()
        Me.L_Notif = New System.Windows.Forms.Label()
        Me.P_img_N = New System.Windows.Forms.Panel()
        Me.Panel_Admin.SuspendLayout()
        Me.Menu.SuspendLayout()
        CType(Me.DataSet_coffe, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VENDEURBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PRODUITBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.P_Notif.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel_Admin
        '
        Me.Panel_Admin.BackColor = System.Drawing.Color.White
        Me.Panel_Admin.Controls.Add(Me.Btn_Vendeur)
        Me.Panel_Admin.Controls.Add(Me.Btn_Produit)
        Me.Panel_Admin.Controls.Add(Me.Btn_Vente)
        Me.Panel_Admin.Controls.Add(Me.Btn_Stat)
        Me.Panel_Admin.FlowDirection = System.Windows.Forms.FlowDirection.TopDown
        Me.Panel_Admin.Location = New System.Drawing.Point(191, 38)
        Me.Panel_Admin.Name = "Panel_Admin"
        Me.Panel_Admin.Size = New System.Drawing.Size(672, 122)
        Me.Panel_Admin.TabIndex = 0
        '
        'Btn_Vendeur
        '
        Me.Btn_Vendeur.BackColor = System.Drawing.Color.Transparent
        Me.Btn_Vendeur.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Vendeur.FlatAppearance.BorderSize = 0
        Me.Btn_Vendeur.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Vendeur.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Vendeur.ImageAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Vendeur.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Vendeur.Name = "Btn_Vendeur"
        Me.Btn_Vendeur.Size = New System.Drawing.Size(162, 113)
        Me.Btn_Vendeur.TabIndex = 0
        Me.Btn_Vendeur.Text = "Vendeurs"
        Me.Btn_Vendeur.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Vendeur.UseVisualStyleBackColor = False
        '
        'Btn_Produit
        '
        Me.Btn_Produit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.Btn_Produit.FlatAppearance.BorderSize = 0
        Me.Btn_Produit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Produit.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Produit.Location = New System.Drawing.Point(171, 3)
        Me.Btn_Produit.Name = "Btn_Produit"
        Me.Btn_Produit.Size = New System.Drawing.Size(162, 113)
        Me.Btn_Produit.TabIndex = 1
        Me.Btn_Produit.Text = "Produits"
        Me.Btn_Produit.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Produit.UseVisualStyleBackColor = True
        '
        'Btn_Vente
        '
        Me.Btn_Vente.FlatAppearance.BorderSize = 0
        Me.Btn_Vente.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Vente.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Vente.Location = New System.Drawing.Point(339, 3)
        Me.Btn_Vente.Name = "Btn_Vente"
        Me.Btn_Vente.Size = New System.Drawing.Size(162, 113)
        Me.Btn_Vente.TabIndex = 2
        Me.Btn_Vente.Text = "Ventes"
        Me.Btn_Vente.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Vente.UseVisualStyleBackColor = True
        '
        'Btn_Stat
        '
        Me.Btn_Stat.FlatAppearance.BorderSize = 0
        Me.Btn_Stat.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Stat.Font = New System.Drawing.Font("Modern No. 20", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Stat.Location = New System.Drawing.Point(507, 3)
        Me.Btn_Stat.Name = "Btn_Stat"
        Me.Btn_Stat.Size = New System.Drawing.Size(162, 113)
        Me.Btn_Stat.TabIndex = 3
        Me.Btn_Stat.Text = "Statistique"
        Me.Btn_Stat.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Btn_Stat.UseVisualStyleBackColor = True
        '
        'Btn_Logout
        '
        Me.Btn_Logout.BackColor = System.Drawing.Color.Black
        Me.Btn_Logout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Logout.Location = New System.Drawing.Point(927, 12)
        Me.Btn_Logout.Name = "Btn_Logout"
        Me.Btn_Logout.Size = New System.Drawing.Size(50, 50)
        Me.Btn_Logout.TabIndex = 1
        Me.Btn_Logout.UseVisualStyleBackColor = False
        '
        'Btn_Clavier
        '
        Me.Btn_Clavier.Location = New System.Drawing.Point(427, 499)
        Me.Btn_Clavier.Name = "Btn_Clavier"
        Me.Btn_Clavier.Size = New System.Drawing.Size(165, 20)
        Me.Btn_Clavier.TabIndex = 2
        Me.Btn_Clavier.Text = "Clavier"
        Me.Btn_Clavier.UseVisualStyleBackColor = True
        '
        'Menu
        '
        Me.Menu.BackColor = System.Drawing.Color.White
        Me.Menu.Controls.Add(Me.Btn_Affich)
        Me.Menu.Controls.Add(Me.Btn_Ajout)
        Me.Menu.Controls.Add(Me.Btn_Modif)
        Me.Menu.Controls.Add(Me.Btn_Supp)
        Me.Menu.Location = New System.Drawing.Point(39, 231)
        Me.Menu.Name = "Menu"
        Me.Menu.Size = New System.Drawing.Size(148, 276)
        Me.Menu.TabIndex = 3
        '
        'Btn_Affich
        '
        Me.Btn_Affich.FlatAppearance.BorderSize = 0
        Me.Btn_Affich.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Affich.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Affich.Location = New System.Drawing.Point(3, 3)
        Me.Btn_Affich.Name = "Btn_Affich"
        Me.Btn_Affich.Size = New System.Drawing.Size(141, 62)
        Me.Btn_Affich.TabIndex = 4
        Me.Btn_Affich.Text = "Lister"
        Me.Btn_Affich.UseVisualStyleBackColor = True
        '
        'Btn_Ajout
        '
        Me.Btn_Ajout.FlatAppearance.BorderSize = 0
        Me.Btn_Ajout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Ajout.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Ajout.Location = New System.Drawing.Point(3, 71)
        Me.Btn_Ajout.Name = "Btn_Ajout"
        Me.Btn_Ajout.Size = New System.Drawing.Size(141, 62)
        Me.Btn_Ajout.TabIndex = 5
        Me.Btn_Ajout.Text = "Ajouter"
        Me.Btn_Ajout.UseVisualStyleBackColor = True
        '
        'Btn_Modif
        '
        Me.Btn_Modif.FlatAppearance.BorderSize = 0
        Me.Btn_Modif.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Modif.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Modif.Location = New System.Drawing.Point(3, 139)
        Me.Btn_Modif.Name = "Btn_Modif"
        Me.Btn_Modif.Size = New System.Drawing.Size(141, 62)
        Me.Btn_Modif.TabIndex = 6
        Me.Btn_Modif.Text = "Modifier"
        Me.Btn_Modif.UseVisualStyleBackColor = True
        '
        'Btn_Supp
        '
        Me.Btn_Supp.FlatAppearance.BorderSize = 0
        Me.Btn_Supp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Btn_Supp.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn_Supp.Location = New System.Drawing.Point(3, 207)
        Me.Btn_Supp.Name = "Btn_Supp"
        Me.Btn_Supp.Size = New System.Drawing.Size(141, 62)
        Me.Btn_Supp.TabIndex = 7
        Me.Btn_Supp.Text = "Supprimer"
        Me.Btn_Supp.UseVisualStyleBackColor = True
        '
        'Titre
        '
        Me.Titre.AutoSize = True
        Me.Titre.BackColor = System.Drawing.Color.Transparent
        Me.Titre.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Titre.Location = New System.Drawing.Point(525, 189)
        Me.Titre.Name = "Titre"
        Me.Titre.Size = New System.Drawing.Size(25, 25)
        Me.Titre.TabIndex = 4
        Me.Titre.Text = "L"
        '
        'DataSet_coffe
        '
        Me.DataSet_coffe.DataSetName = "DataSet_coffe"
        Me.DataSet_coffe.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VENDEURBindingSource
        '
        Me.VENDEURBindingSource.DataMember = "VENDEUR"
        Me.VENDEURBindingSource.DataSource = Me.DataSet_coffe
        '
        'VENDEURTableAdapter
        '
        Me.VENDEURTableAdapter.ClearBeforeFill = True
        '
        'PRODUITBindingSource
        '
        Me.PRODUITBindingSource.DataMember = "PRODUIT"
        Me.PRODUITBindingSource.DataSource = Me.DataSet_coffe
        '
        'PRODUITTableAdapter
        '
        Me.PRODUITTableAdapter.ClearBeforeFill = True
        '
        'P_Notif
        '
        Me.P_Notif.BackColor = System.Drawing.Color.Transparent
        Me.P_Notif.Controls.Add(Me.L_MSG)
        Me.P_Notif.Controls.Add(Me.L_Notif)
        Me.P_Notif.Controls.Add(Me.P_img_N)
        Me.P_Notif.Location = New System.Drawing.Point(12, 75)
        Me.P_Notif.Name = "P_Notif"
        Me.P_Notif.Size = New System.Drawing.Size(200, 79)
        Me.P_Notif.TabIndex = 5
        '
        'L_MSG
        '
        Me.L_MSG.AutoSize = True
        Me.L_MSG.Location = New System.Drawing.Point(13, 56)
        Me.L_MSG.Name = "L_MSG"
        Me.L_MSG.Size = New System.Drawing.Size(39, 13)
        Me.L_MSG.TabIndex = 2
        Me.L_MSG.Text = "Label2"
        '
        'L_Notif
        '
        Me.L_Notif.AutoSize = True
        Me.L_Notif.Location = New System.Drawing.Point(47, 13)
        Me.L_Notif.Name = "L_Notif"
        Me.L_Notif.Size = New System.Drawing.Size(39, 13)
        Me.L_Notif.TabIndex = 1
        Me.L_Notif.Text = "Label1"
        '
        'P_img_N
        '
        Me.P_img_N.Location = New System.Drawing.Point(3, 3)
        Me.P_img_N.Name = "P_img_N"
        Me.P_img_N.Size = New System.Drawing.Size(38, 37)
        Me.P_img_N.TabIndex = 0
        '
        'Admin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1000, 519)
        Me.Controls.Add(Me.P_Notif)
        Me.Controls.Add(Me.Titre)
        Me.Controls.Add(Me.Menu)
        Me.Controls.Add(Me.Btn_Clavier)
        Me.Controls.Add(Me.Btn_Logout)
        Me.Controls.Add(Me.Panel_Admin)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Admin"
        Me.Text = "Admin"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel_Admin.ResumeLayout(False)
        Me.Menu.ResumeLayout(False)
        CType(Me.DataSet_coffe, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VENDEURBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PRODUITBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.P_Notif.ResumeLayout(False)
        Me.P_Notif.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Panel_Admin As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Btn_Vendeur As System.Windows.Forms.Button
    Friend WithEvents Btn_Produit As System.Windows.Forms.Button
    Friend WithEvents Btn_Vente As System.Windows.Forms.Button
    Friend WithEvents Btn_Stat As System.Windows.Forms.Button
    Friend WithEvents Btn_Logout As System.Windows.Forms.Button
    Friend WithEvents Btn_Clavier As System.Windows.Forms.Button
    Friend WithEvents Menu As System.Windows.Forms.FlowLayoutPanel
    Friend WithEvents Btn_Affich As System.Windows.Forms.Button
    Friend WithEvents Btn_Ajout As System.Windows.Forms.Button
    Friend WithEvents Btn_Modif As System.Windows.Forms.Button
    Friend WithEvents Btn_Supp As System.Windows.Forms.Button
    Friend WithEvents Titre As System.Windows.Forms.Label
    Friend WithEvents DataSet_coffe As Projet_Final.DataSet_coffe
    Friend WithEvents VENDEURBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents VENDEURTableAdapter As Projet_Final.DataSet_coffeTableAdapters.VENDEURTableAdapter
    Friend WithEvents PRODUITBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PRODUITTableAdapter As Projet_Final.DataSet_coffeTableAdapters.PRODUITTableAdapter
    Friend WithEvents P_Notif As System.Windows.Forms.Panel
    Friend WithEvents L_MSG As System.Windows.Forms.Label
    Friend WithEvents L_Notif As System.Windows.Forms.Label
    Friend WithEvents P_img_N As System.Windows.Forms.Panel
End Class
