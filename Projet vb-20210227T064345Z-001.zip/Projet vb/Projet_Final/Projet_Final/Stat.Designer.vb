﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Stat
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim ReportDataSource1 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim ReportDataSource2 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim ReportDataSource3 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Dim ReportDataSource4 As Microsoft.Reporting.WinForms.ReportDataSource = New Microsoft.Reporting.WinForms.ReportDataSource()
        Me.VENTEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DataSet2 = New Projet_Final.DataSet2()
        Me.C_A_V = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.VENTETableAdapter = New Projet_Final.DataSet2TableAdapters.VENTETableAdapter()
        Me.bnt_C_A_V = New System.Windows.Forms.Button()
        Me.Btn_E_V_M = New System.Windows.Forms.Button()
        Me.Btn_Benfice_M = New System.Windows.Forms.Button()
        Me.Btn_Benefice_A = New System.Windows.Forms.Button()
        Me.E_V_M = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.Benefice_M = New Microsoft.Reporting.WinForms.ReportViewer()
        Me.Benefice_A = New Microsoft.Reporting.WinForms.ReportViewer()
        CType(Me.VENTEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'VENTEBindingSource
        '
        Me.VENTEBindingSource.DataMember = "VENTE"
        Me.VENTEBindingSource.DataSource = Me.DataSet2
        '
        'DataSet2
        '
        Me.DataSet2.DataSetName = "DataSet2"
        Me.DataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'C_A_V
        '
        ReportDataSource1.Name = "DataSet1"
        ReportDataSource1.Value = Me.VENTEBindingSource
        Me.C_A_V.LocalReport.DataSources.Add(ReportDataSource1)
        Me.C_A_V.LocalReport.ReportEmbeddedResource = "Projet_Final.CF_Vendeur.rdlc"
        Me.C_A_V.Location = New System.Drawing.Point(45, 42)
        Me.C_A_V.Name = "C_A_V"
        Me.C_A_V.Size = New System.Drawing.Size(547, 338)
        Me.C_A_V.TabIndex = 0
        '
        'VENTETableAdapter
        '
        Me.VENTETableAdapter.ClearBeforeFill = True
        '
        'bnt_C_A_V
        '
        Me.bnt_C_A_V.Location = New System.Drawing.Point(32, 12)
        Me.bnt_C_A_V.Name = "bnt_C_A_V"
        Me.bnt_C_A_V.Size = New System.Drawing.Size(145, 23)
        Me.bnt_C_A_V.TabIndex = 1
        Me.bnt_C_A_V.Text = "Chiffre d'affaire par vendeur"
        Me.bnt_C_A_V.UseVisualStyleBackColor = True
        '
        'Btn_E_V_M
        '
        Me.Btn_E_V_M.Location = New System.Drawing.Point(183, 12)
        Me.Btn_E_V_M.Name = "Btn_E_V_M"
        Me.Btn_E_V_M.Size = New System.Drawing.Size(153, 23)
        Me.Btn_E_V_M.TabIndex = 2
        Me.Btn_E_V_M.Text = "Evaluation de vente par mois"
        Me.Btn_E_V_M.UseVisualStyleBackColor = True
        '
        'Btn_Benfice_M
        '
        Me.Btn_Benfice_M.Location = New System.Drawing.Point(373, 12)
        Me.Btn_Benfice_M.Name = "Btn_Benfice_M"
        Me.Btn_Benfice_M.Size = New System.Drawing.Size(119, 23)
        Me.Btn_Benfice_M.TabIndex = 3
        Me.Btn_Benfice_M.Text = "Bénéfice mensuelle"
        Me.Btn_Benfice_M.UseVisualStyleBackColor = True
        '
        'Btn_Benefice_A
        '
        Me.Btn_Benefice_A.Location = New System.Drawing.Point(498, 12)
        Me.Btn_Benefice_A.Name = "Btn_Benefice_A"
        Me.Btn_Benefice_A.Size = New System.Drawing.Size(133, 23)
        Me.Btn_Benefice_A.TabIndex = 4
        Me.Btn_Benefice_A.Text = "Bénéfice Annuelle"
        Me.Btn_Benefice_A.UseVisualStyleBackColor = True
        '
        'E_V_M
        '
        ReportDataSource2.Name = "DataSet1"
        ReportDataSource2.Value = Me.VENTEBindingSource
        Me.E_V_M.LocalReport.DataSources.Add(ReportDataSource2)
        Me.E_V_M.LocalReport.ReportEmbeddedResource = "Projet_Final.E_V_mois.rdlc"
        Me.E_V_M.Location = New System.Drawing.Point(45, 42)
        Me.E_V_M.Name = "E_V_M"
        Me.E_V_M.Size = New System.Drawing.Size(547, 338)
        Me.E_V_M.TabIndex = 5
        '
        'Benefice_M
        '
        ReportDataSource3.Name = "DataSet1"
        ReportDataSource3.Value = Me.VENTEBindingSource
        Me.Benefice_M.LocalReport.DataSources.Add(ReportDataSource3)
        Me.Benefice_M.LocalReport.ReportEmbeddedResource = "Projet_Final.Benefice_M.rdlc"
        Me.Benefice_M.Location = New System.Drawing.Point(45, 42)
        Me.Benefice_M.Name = "Benefice_M"
        Me.Benefice_M.Size = New System.Drawing.Size(547, 338)
        Me.Benefice_M.TabIndex = 6
        '
        'Benefice_A
        '
        ReportDataSource4.Name = "DataSet1"
        ReportDataSource4.Value = Me.VENTEBindingSource
        Me.Benefice_A.LocalReport.DataSources.Add(ReportDataSource4)
        Me.Benefice_A.LocalReport.ReportEmbeddedResource = "Projet_Final.Benefice_A.rdlc"
        Me.Benefice_A.Location = New System.Drawing.Point(45, 42)
        Me.Benefice_A.Name = "Benefice_A"
        Me.Benefice_A.Size = New System.Drawing.Size(547, 338)
        Me.Benefice_A.TabIndex = 7
        '
        'Stat
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(751, 481)
        Me.Controls.Add(Me.Benefice_A)
        Me.Controls.Add(Me.Benefice_M)
        Me.Controls.Add(Me.E_V_M)
        Me.Controls.Add(Me.Btn_Benefice_A)
        Me.Controls.Add(Me.Btn_Benfice_M)
        Me.Controls.Add(Me.Btn_E_V_M)
        Me.Controls.Add(Me.bnt_C_A_V)
        Me.Controls.Add(Me.C_A_V)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "Stat"
        Me.Opacity = 0.9R
        Me.Text = "Stat"
        CType(Me.VENTEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents C_A_V As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents VENTEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents DataSet2 As Projet_Final.DataSet2
    Friend WithEvents VENTETableAdapter As Projet_Final.DataSet2TableAdapters.VENTETableAdapter
    Friend WithEvents bnt_C_A_V As System.Windows.Forms.Button
    Friend WithEvents Btn_E_V_M As System.Windows.Forms.Button
    Friend WithEvents Btn_Benfice_M As System.Windows.Forms.Button
    Friend WithEvents Btn_Benefice_A As System.Windows.Forms.Button
    Friend WithEvents E_V_M As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents Benefice_M As Microsoft.Reporting.WinForms.ReportViewer
    Friend WithEvents Benefice_A As Microsoft.Reporting.WinForms.ReportViewer
End Class
